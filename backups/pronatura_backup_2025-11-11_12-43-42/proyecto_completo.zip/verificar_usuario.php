<?php
require_once __DIR__ . '/../api/db_connection.php';
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Verificar Usuario Actual</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 900px; margin: 20px auto; padding: 20px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #4caf50; background: #e8f5e9; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .error { color: #f44336; background: #ffebee; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .info { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 10px 0; }
        h1 { color: #2c7a7b; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #2c7a7b; color: white; }
        .btn { display: inline-block; padding: 10px 20px; background: #2c7a7b; color: white; text-decoration: none; border-radius: 5px; margin: 10px 5px; }
        .btn:hover { background: #1a5f5f; }
    </style>
</head>
<body>
    <div class="container">
        <h1>👤 Verificar Usuario y Sesión</h1>
        
        <div class="info">
            <h3>📋 Información de Sesión (localStorage):</h3>
            <p>Esta información se obtiene del navegador (localStorage):</p>
            <div id="sessionInfo" style="background: #f5f5f5; padding: 10px; border-radius: 5px; margin: 10px 0;">
                <p>Cargando información de sesión...</p>
            </div>
        </div>
        
        <?php
        try {
            $conn = getDB();
            $config = json_decode(file_get_contents(__DIR__ . '/../config/config.json'), true);
            $dbName = $config['database']['database'];
            
            echo '<div class="info">';
            echo '<h3>📊 Base de Datos: ' . htmlspecialchars($dbName) . '</h3>';
            echo '</div>';
            
            // Mostrar todos los usuarios
            $stmt = $conn->query("SELECT id, nombre, email, rol, fecha_registro, fecha_ultimo_acceso, activo FROM usuarios ORDER BY fecha_registro DESC");
            $usuarios = $stmt->fetchAll();
            
            echo '<div class="success">';
            echo '<h3>✅ Usuarios registrados en la base de datos (' . count($usuarios) . '):</h3>';
            
            if (count($usuarios) > 0) {
                echo '<table>';
                echo '<tr><th>ID</th><th>Nombre</th><th>Email</th><th>Rol</th><th>Fecha Registro</th><th>Último Acceso</th><th>Activo</th></tr>';
                foreach ($usuarios as $usuario) {
                    $highlight = '';
                    echo '<tr' . $highlight . '>';
                    echo '<td>' . htmlspecialchars($usuario['id']) . '</td>';
                    echo '<td><strong>' . htmlspecialchars($usuario['nombre']) . '</strong></td>';
                    echo '<td>' . htmlspecialchars($usuario['email']) . '</td>';
                    echo '<td>' . htmlspecialchars($usuario['rol']) . '</td>';
                    echo '<td>' . htmlspecialchars($usuario['fecha_registro']) . '</td>';
                    echo '<td>' . ($usuario['fecha_ultimo_acceso'] ? htmlspecialchars($usuario['fecha_ultimo_acceso']) : 'Nunca') . '</td>';
                    echo '<td>' . ($usuario['activo'] ? '✅ Sí' : '❌ No') . '</td>';
                    echo '</tr>';
                }
                echo '</table>';
            } else {
                echo '<p>No hay usuarios registrados aún.</p>';
            }
            echo '</div>';
            
        } catch (Exception $e) {
            echo '<div class="error">';
            echo '<h3>❌ Error:</h3>';
            echo '<p>' . htmlspecialchars($e->getMessage()) . '</p>';
            echo '</div>';
        }
        ?>
        
        <div class="info" style="margin-top: 20px;">
            <h3>📝 Instrucciones:</h3>
            <ol>
                <li><strong>En phpMyAdmin:</strong> Selecciona la base de datos <strong>"pronatura"</strong> (no "db") en el panel izquierdo</li>
                <li><strong>Verifica tu sesión:</strong> Abre la consola del navegador (F12) y revisa la información de sesión arriba</li>
                <li><strong>Si no hay sesión:</strong> Inicia sesión desde <a href="login.html">login.html</a></li>
            </ol>
            <p>
                <a href="index.html" class="btn">Ir a la Aplicación</a>
                <a href="login.html" class="btn">Iniciar Sesión</a>
                <a href="registro.html" class="btn">Registrarse</a>
            </p>
        </div>
    </div>
    
    <script>
        // Mostrar información de sesión del localStorage
        function mostrarSesion() {
            const sessionInfo = document.getElementById('sessionInfo');
            try {
                const session = localStorage.getItem('current_session');
                if (session) {
                    const user = JSON.parse(session);
                    sessionInfo.innerHTML = `
                        <p><strong>✅ Sesión activa:</strong></p>
                        <ul>
                            <li><strong>ID:</strong> ${user.id || 'N/A'}</li>
                            <li><strong>Nombre:</strong> ${user.nombre || 'N/A'}</li>
                            <li><strong>Email:</strong> ${user.email || 'N/A'}</li>
                            <li><strong>Fecha Registro:</strong> ${user.fechaRegistro || 'N/A'}</li>
                        </ul>
                    `;
                } else {
                    sessionInfo.innerHTML = '<p><strong>❌ No hay sesión activa</strong></p><p>Necesitas iniciar sesión.</p>';
                }
            } catch (e) {
                sessionInfo.innerHTML = '<p><strong>❌ Error al leer la sesión:</strong> ' + e.message + '</p>';
            }
        }
        
        mostrarSesion();
    </script>
</body>
</html>


<?php
require_once __DIR__ . '/../api/db_connection.php';

header('Content-Type: text/html; charset=utf-8');

try {
    $conn = getDB();
    
    echo "<h2>Crear Tablas de Administración</h2>";
    
    // 1. Crear tabla logs_admin
    echo "<p>1. Creando tabla logs_admin...</p>";
    $createLogs = "
    CREATE TABLE IF NOT EXISTS logs_admin (
        id INT PRIMARY KEY AUTO_INCREMENT,
        admin_id INT NOT NULL,
        tipo_accion VARCHAR(50) NOT NULL,
        entidad_afectada VARCHAR(50) NULL,
        entidad_id INT NULL,
        descripcion TEXT NULL,
        datos_anteriores JSON NULL,
        datos_nuevos JSON NULL,
        ip_address VARCHAR(45) NULL,
        user_agent VARCHAR(500) NULL,
        fecha_accion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (admin_id) REFERENCES usuarios(id) ON DELETE CASCADE,
        INDEX idx_admin (admin_id),
        INDEX idx_tipo_accion (tipo_accion),
        INDEX idx_fecha (fecha_accion),
        INDEX idx_entidad (entidad_afectada, entidad_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $conn->exec($createLogs);
    echo "<p style='color: green;'>✅ Tabla logs_admin creada</p>";
    
    // 2. Crear tabla configuraciones
    echo "<p>2. Creando tabla configuraciones...</p>";
    $createConfig = "
    CREATE TABLE IF NOT EXISTS configuraciones (
        id INT PRIMARY KEY AUTO_INCREMENT,
        clave VARCHAR(100) NOT NULL UNIQUE,
        valor TEXT NULL,
        tipo ENUM('texto', 'numero', 'booleano', 'json') DEFAULT 'texto',
        descripcion TEXT NULL,
        categoria VARCHAR(50) NULL,
        editable BOOLEAN DEFAULT TRUE,
        fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        fecha_actualizacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_clave (clave),
        INDEX idx_categoria (categoria)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $conn->exec($createConfig);
    echo "<p style='color: green;'>✅ Tabla configuraciones creada</p>";
    
    // 3. Crear tabla notificaciones
    echo "<p>3. Creando tabla notificaciones...</p>";
    $createNotif = "
    CREATE TABLE IF NOT EXISTS notificaciones (
        id INT PRIMARY KEY AUTO_INCREMENT,
        usuario_id INT NULL,
        tipo ENUM('info', 'success', 'warning', 'error', 'system') DEFAULT 'info',
        titulo VARCHAR(255) NOT NULL,
        mensaje TEXT NOT NULL,
        enlace VARCHAR(500) NULL,
        leida BOOLEAN DEFAULT FALSE,
        fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        fecha_leida DATETIME NULL,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
        INDEX idx_usuario (usuario_id),
        INDEX idx_leida (leida),
        INDEX idx_fecha (fecha_creacion),
        INDEX idx_tipo (tipo)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $conn->exec($createNotif);
    echo "<p style='color: green;'>✅ Tabla notificaciones creada</p>";
    
    // 4. Crear tabla reportes
    echo "<p>4. Creando tabla reportes...</p>";
    $createReportes = "
    CREATE TABLE IF NOT EXISTS reportes (
        id INT PRIMARY KEY AUTO_INCREMENT,
        usuario_id INT NOT NULL,
        nombre VARCHAR(255) NOT NULL,
        tipo_reporte VARCHAR(50) NOT NULL,
        parametros JSON NULL,
        datos JSON NULL,
        formato ENUM('json', 'csv', 'pdf', 'xlsx') DEFAULT 'json',
        ruta_archivo VARCHAR(500) NULL,
        fecha_generacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        fecha_desde DATE NULL,
        fecha_hasta DATE NULL,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
        INDEX idx_usuario (usuario_id),
        INDEX idx_tipo (tipo_reporte),
        INDEX idx_fecha (fecha_generacion)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $conn->exec($createReportes);
    echo "<p style='color: green;'>✅ Tabla reportes creada</p>";
    
    // 5. Crear vistas
    echo "<p>5. Creando vistas...</p>";
    
    $createViewLogs = "
    CREATE OR REPLACE VIEW vista_logs_admin AS
    SELECT 
        l.id,
        l.admin_id,
        l.tipo_accion,
        l.entidad_afectada,
        l.entidad_id,
        l.descripcion,
        l.fecha_accion,
        l.ip_address,
        u.nombre AS admin_nombre,
        u.email AS admin_email,
        u.rol AS admin_rol
    FROM logs_admin l
    INNER JOIN usuarios u ON l.admin_id = u.id
    ORDER BY l.fecha_accion DESC";
    
    $conn->exec($createViewLogs);
    echo "<p style='color: green;'>✅ Vista vista_logs_admin creada</p>";
    
    $createViewNotif = "
    CREATE OR REPLACE VIEW vista_notificaciones AS
    SELECT 
        n.id,
        n.usuario_id,
        n.tipo,
        n.titulo,
        n.mensaje,
        n.enlace,
        n.leida,
        n.fecha_creacion,
        n.fecha_leida,
        u.nombre AS usuario_nombre,
        u.email AS usuario_email
    FROM notificaciones n
    LEFT JOIN usuarios u ON n.usuario_id = u.id
    ORDER BY n.fecha_creacion DESC";
    
    $conn->exec($createViewNotif);
    echo "<p style='color: green;'>✅ Vista vista_notificaciones creada</p>";
    
    // 6. Insertar configuraciones iniciales
    echo "<p>6. Insertando configuraciones iniciales...</p>";
    $configs = [
        ['sistema_nombre', 'Contraloría Social Tamaulipas', 'texto', 'Nombre del sistema', 'general'],
        ['sistema_version', '1.0.0', 'texto', 'Versión del sistema', 'general'],
        ['registros_por_pagina', '25', 'numero', 'Número de registros por página', 'general'],
        ['notificaciones_activas', 'true', 'booleano', 'Activar sistema de notificaciones', 'notificaciones'],
        ['mantenimiento', 'false', 'booleano', 'Modo de mantenimiento', 'sistema']
    ];
    
    $stmt = $conn->prepare("INSERT INTO configuraciones (clave, valor, tipo, descripcion, categoria) 
                            VALUES (?, ?, ?, ?, ?)
                            ON DUPLICATE KEY UPDATE valor = valor");
    
    $insertados = 0;
    foreach ($configs as $config) {
        $stmt->execute($config);
        $insertados++;
    }
    echo "<p style='color: green;'>✅ $insertados configuraciones insertadas</p>";
    
    // Verificar que las tablas existen
    $tablas = ['logs_admin', 'configuraciones', 'notificaciones', 'reportes'];
    $existentes = 0;
    
    foreach ($tablas as $tabla) {
        $stmt = $conn->query("SHOW TABLES LIKE '$tabla'");
        if ($stmt->rowCount() > 0) {
            $existentes++;
        }
    }
    
    echo "<hr>";
    if ($existentes === count($tablas)) {
        echo "<p style='color: green; font-size: 1.2em;'><strong>✅ Todas las tablas de administración creadas exitosamente</strong></p>";
        echo "<p><strong>Tablas creadas:</strong></p>";
        echo "<ul>";
        echo "<li>logs_admin - Registro de acciones de administradores (auditoría)</li>";
        echo "<li>configuraciones - Configuraciones del sistema</li>";
        echo "<li>notificaciones - Notificaciones para usuarios</li>";
        echo "<li>reportes - Reportes generados</li>";
        echo "</ul>";
        echo "<p><strong>Vistas creadas:</strong></p>";
        echo "<ul>";
        echo "<li>vista_logs_admin - Vista de logs con información del administrador</li>";
        echo "<li>vista_notificaciones - Vista de notificaciones con información del usuario</li>";
        echo "</ul>";
    } else {
        echo "<p style='color: red;'>❌ Error: No todas las tablas se crearon correctamente</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p style='color: red;'>Stack trace: " . htmlspecialchars($e->getTraceAsString()) . "</p>";
}
?>


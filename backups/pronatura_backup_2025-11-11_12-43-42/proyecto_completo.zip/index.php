<?php
// Redirigir a la página principal
header('Location: pages/index.html');
exit;
?>


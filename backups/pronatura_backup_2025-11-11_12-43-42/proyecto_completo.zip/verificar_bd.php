<?php
require_once __DIR__ . '/../api/db_connection.php';
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Verificar Base de Datos</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 900px; margin: 20px auto; padding: 20px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #4caf50; background: #e8f5e9; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .error { color: #f44336; background: #ffebee; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .info { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 10px 0; }
        h1 { color: #2c7a7b; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #2c7a7b; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Verificación de Base de Datos</h1>
        
        <?php
        try {
            $conn = getDB();
            $config = json_decode(file_get_contents(__DIR__ . '/../config/config.json'), true);
            $dbName = $config['database']['database'];
            
            echo '<div class="info">';
            echo '<h3>📋 Configuración:</h3>';
            echo '<p><strong>Base de datos configurada:</strong> ' . htmlspecialchars($dbName) . '</p>';
            echo '</div>';
            
            // Verificar si la tabla usuarios existe
            $stmt = $conn->query("SHOW TABLES LIKE 'usuarios'");
            if ($stmt->rowCount() > 0) {
                echo '<div class="success">';
                echo '<h3>✅ Tabla "usuarios" existe</h3>';
                echo '</div>';
                
                // Mostrar todos los usuarios
                $stmt = $conn->query("SELECT id, nombre, email, rol, fecha_registro, activo FROM usuarios ORDER BY fecha_registro DESC");
                $usuarios = $stmt->fetchAll();
                
                echo '<div class="info">';
                echo '<h3>👥 Usuarios registrados (' . count($usuarios) . '):</h3>';
                
                if (count($usuarios) > 0) {
                    echo '<table>';
                    echo '<tr><th>ID</th><th>Nombre</th><th>Email</th><th>Rol</th><th>Fecha Registro</th><th>Activo</th></tr>';
                    foreach ($usuarios as $usuario) {
                        echo '<tr>';
                        echo '<td>' . htmlspecialchars($usuario['id']) . '</td>';
                        echo '<td>' . htmlspecialchars($usuario['nombre']) . '</td>';
                        echo '<td>' . htmlspecialchars($usuario['email']) . '</td>';
                        echo '<td>' . htmlspecialchars($usuario['rol']) . '</td>';
                        echo '<td>' . htmlspecialchars($usuario['fecha_registro']) . '</td>';
                        echo '<td>' . ($usuario['activo'] ? 'Sí' : 'No') . '</td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                } else {
                    echo '<p>No hay usuarios registrados aún.</p>';
                }
                echo '</div>';
            } else {
                echo '<div class="error">';
                echo '<h3>❌ La tabla "usuarios" no existe</h3>';
                echo '<p>Necesitas ejecutar el script db.sql para crear las tablas.</p>';
                echo '</div>';
            }
            
        } catch (Exception $e) {
            echo '<div class="error">';
            echo '<h3>❌ Error:</h3>';
            echo '<p>' . htmlspecialchars($e->getMessage()) . '</p>';
            echo '</div>';
        }
        ?>
        
        <div class="info" style="margin-top: 20px;">
            <h3>📝 Nota importante:</h3>
            <p>La aplicación está configurada para usar la base de datos <strong>"pronatura"</strong>.</p>
            <p>Si estás viendo otra base de datos en phpMyAdmin (como "db"), asegúrate de revisar la base de datos correcta.</p>
            <p><a href="http://localhost/phpmyadmin" target="_blank">Abrir phpMyAdmin</a></p>
        </div>
    </div>
</body>
</html>


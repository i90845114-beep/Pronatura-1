<?php
require_once __DIR__ . '/../api/db_connection.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Migración de Usuarios - ProNatura</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .success {
            color: #4caf50;
            background: #e8f5e9;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .error {
            color: #f44336;
            background: #ffebee;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .info {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        h1 {
            color: #2c7a7b;
        }
        pre {
            background: #f5f5f5;
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
        }
        button {
            background: #2c7a7b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin: 5px;
        }
        button:hover {
            background: #1a5a5b;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>👥 Migración de Usuarios a Base de Datos</h1>
        
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
            try {
                $conn = getDB();
                
                if ($_POST['action'] === 'create_test') {
                    // Crear usuarios de prueba
                    $testUsers = [
                        ['nombre' => 'Admin', 'email' => 'admin@pronatura.com', 'password' => 'admin123', 'rol' => 'admin'],
                        ['nombre' => 'Usuario Test', 'email' => 'usuario@pronatura.com', 'password' => 'usuario123', 'rol' => 'usuario']
                    ];
                    
                    $created = 0;
                    foreach ($testUsers as $user) {
                        // Hash simple de contraseña (deberías usar password_hash en producción)
                        $passwordHash = password_hash($user['password'], PASSWORD_DEFAULT);
                        
                        $stmt = $conn->prepare("INSERT INTO usuarios (nombre, email, password_hash, rol) VALUES (?, ?, ?, ?)");
                        try {
                            $stmt->execute([$user['nombre'], $user['email'], $passwordHash, $user['rol']]);
                            $created++;
                            echo '<div class="success">✓ Usuario creado: ' . htmlspecialchars($user['email']) . ' (Rol: ' . $user['rol'] . ')</div>';
                        } catch (PDOException $e) {
                            if ($e->getCode() == 23000) {
                                echo '<div class="info">⚠ Usuario ya existe: ' . htmlspecialchars($user['email']) . '</div>';
                            } else {
                                echo '<div class="error">✗ Error al crear usuario ' . htmlspecialchars($user['email']) . ': ' . htmlspecialchars($e->getMessage()) . '</div>';
                            }
                        }
                    }
                    
                    if ($created > 0) {
                        echo '<div class="success"><h3>✅ ' . $created . ' usuario(s) creado(s) exitosamente</h3></div>';
                    }
                    
                } elseif ($_POST['action'] === 'show_users') {
                    // Mostrar usuarios existentes
                    $stmt = $conn->query("SELECT id, nombre, email, rol, fecha_registro, activo FROM usuarios ORDER BY fecha_registro DESC");
                    $users = $stmt->fetchAll();
                    
                    if (count($users) > 0) {
                        echo '<div class="info"><h3>📋 Usuarios en la Base de Datos:</h3>';
                        echo '<table style="width: 100%; border-collapse: collapse;">';
                        echo '<tr style="background: #2c7a7b; color: white;"><th style="padding: 10px; text-align: left;">ID</th><th style="padding: 10px; text-align: left;">Nombre</th><th style="padding: 10px; text-align: left;">Email</th><th style="padding: 10px; text-align: left;">Rol</th><th style="padding: 10px; text-align: left;">Fecha Registro</th></tr>';
                        foreach ($users as $user) {
                            echo '<tr style="border-bottom: 1px solid #ddd;">';
                            echo '<td style="padding: 10px;">' . htmlspecialchars($user['id']) . '</td>';
                            echo '<td style="padding: 10px;">' . htmlspecialchars($user['nombre']) . '</td>';
                            echo '<td style="padding: 10px;">' . htmlspecialchars($user['email']) . '</td>';
                            echo '<td style="padding: 10px;">' . htmlspecialchars($user['rol']) . '</td>';
                            echo '<td style="padding: 10px;">' . htmlspecialchars($user['fecha_registro']) . '</td>';
                            echo '</tr>';
                        }
                        echo '</table></div>';
                    } else {
                        echo '<div class="info">No hay usuarios en la base de datos.</div>';
                    }
                }
                
            } catch (Exception $e) {
                echo '<div class="error">Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
            }
        }
        ?>
        
        <div class="info">
            <h3>📝 Instrucciones:</h3>
            <p>La aplicación actualmente usa <strong>localStorage</strong> para almacenar usuarios. Para migrar a la base de datos:</p>
            <ol>
                <li>Crea usuarios de prueba directamente en la base de datos</li>
                <li>O modifica la aplicación para que use la base de datos en lugar de localStorage</li>
            </ol>
        </div>
        
        <form method="POST" style="margin-top: 20px;">
            <button type="submit" name="action" value="create_test">Crear Usuarios de Prueba</button>
            <button type="submit" name="action" value="show_users">Mostrar Usuarios Existentes</button>
        </form>
        
        <div class="info" style="margin-top: 20px;">
            <h3>🔐 Credenciales de Prueba (si creas usuarios de prueba):</h3>
            <ul>
                <li><strong>Admin:</strong> admin@pronatura.com / admin123</li>
                <li><strong>Usuario:</strong> usuario@pronatura.com / usuario123</li>
            </ul>
            <p><strong>Nota:</strong> Estos usuarios se crearán con contraseñas hasheadas usando password_hash() de PHP.</p>
        </div>
        
        <p style="margin-top: 20px;"><a href="test_connection.php">← Volver al test de conexión</a></p>
    </div>
</body>
</html>


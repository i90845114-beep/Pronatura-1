// Sistema de autenticación
// Almacenamiento en localStorage (fácil migración a base de datos después)

const AUTH_STORAGE_KEY = 'auth_users';
const SESSION_KEY = 'current_session';

// Inicializar sistema de autenticación
const authSystem = {
    // Obtener todos los usuarios
    getUsers() {
        const stored = localStorage.getItem(AUTH_STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    },
    
    // Guardar usuarios
    saveUsers(users) {
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(users));
    },
    
    // Registrar nuevo usuario
    async register(nombre, email, password) {
        try {
            const response = await fetch('../api/api.php?action=register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    nombre: nombre,
                    email: email,
                    password: password
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                // Iniciar sesión automáticamente después del registro
                this.setSession(data.user);
                return { success: true };
            } else {
                console.error('Error al registrar:', data.message);
                return { success: false, message: data.message || 'Error desconocido al registrar' };
            }
        } catch (error) {
            console.error('Error de conexión:', error);
            return { success: false, message: 'Error de conexión. Verifica que el servidor esté corriendo.' };
        }
    },
    
    // Iniciar sesión
    async login(email, password) {
        try {
            const response = await fetch('../api/api.php?action=login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: email,
                    password: password
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.setSession(data.user);
                return { success: true };
            } else {
                console.error('Error al iniciar sesión:', data.message);
                return { success: false, message: data.message || 'Error desconocido al iniciar sesión' };
            }
        } catch (error) {
            console.error('Error de conexión:', error);
            return { success: false, message: 'Error de conexión. Verifica que el servidor esté corriendo.' };
        }
    },
    
    // Cerrar sesión
    logout() {
        localStorage.removeItem(SESSION_KEY);
    },
    
    // Verificar si hay sesión activa
    isAuthenticated() {
        const session = this.getSession();
        return session !== null;
    },
    
    // Obtener usuario actual
    getCurrentUser() {
        return this.getSession();
    },
    
    // Establecer sesión
    setSession(user) {
        // No guardar la contraseña en la sesión
        const sessionData = {
            id: user.id,
            nombre: user.nombre,
            email: user.email,
            fechaRegistro: user.fechaRegistro,
            rol: user.rol || 'usuario' // Incluir el rol del usuario
        };
        localStorage.setItem(SESSION_KEY, JSON.stringify(sessionData));
    },
    
    // Obtener sesión
    getSession() {
        const stored = localStorage.getItem(SESSION_KEY);
        return stored ? JSON.parse(stored) : null;
    },
    
    // Hash simple de contraseña (en producción usar bcrypt o similar)
    hashPassword(password) {
        // Hash simple para desarrollo
        // En producción, esto debe hacerse en el servidor con bcrypt
        let hash = 0;
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convertir a 32bit integer
        }
        return hash.toString();
    },
    
    // Requerir autenticación (redirigir si no está autenticado)
    requireAuth() {
        if (!this.isAuthenticated()) {
            window.location.href = 'login.html';
            return false;
        }
        return true;
    }
};

// Exportar para uso global
window.authSystem = authSystem;

// Auto-redirigir si no está autenticado en páginas protegidas
document.addEventListener('DOMContentLoaded', () => {
    // Lista de páginas que requieren autenticación
    const protectedPages = ['index.html', 'nuevo-registro.html', 'mapa-consolidado.html', 'bloc-notas.html'];
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    
    if (protectedPages.includes(currentPage)) {
        // Verificar si viene del panel de administración
        const fromAdmin = sessionStorage.getItem('editingFromAdmin') === 'true';
        
        if (fromAdmin) {
            // Si viene del admin, verificar autenticación de admin
            // PERO no redirigir si no hay sesión - permitir acceso para mantener contexto
            if (window.adminAuthSystem && window.adminAuthSystem.isAuthenticated()) {
                console.log('✅ Autenticación de administrador válida');
                return; // Permitir acceso
            } else {
                // Si no hay sesión de admin pero viene del admin, permitir acceso de todas formas
                // El formulario manejará la autenticación al guardar
                console.log('⚠️ No hay sesión de admin activa, pero viene del panel admin - permitiendo acceso');
                return; // Permitir acceso para mantener contexto
            }
        } else {
            // Si no viene del admin, verificar autenticación de usuario normal
            if (!authSystem.isAuthenticated()) {
                window.location.href = 'login.html';
            }
        }
    }
    
    // Si está en login/registro y ya está autenticado, redirigir a index
    if ((currentPage === 'login.html' || currentPage === 'registro.html') && authSystem.isAuthenticated()) {
        window.location.href = 'index.html';
    }
});


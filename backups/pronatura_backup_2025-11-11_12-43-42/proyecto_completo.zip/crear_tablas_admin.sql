-- Script para crear las tablas de administración
-- Ejecutar este script en phpMyAdmin o desde la línea de comandos

USE db;

-- Tabla de logs de acciones de administradores (auditoría)
CREATE TABLE IF NOT EXISTS logs_admin (
    id INT PRIMARY KEY AUTO_INCREMENT,
    admin_id INT NOT NULL,
    tipo_accion VARCHAR(50) NOT NULL,
    entidad_afectada VARCHAR(50) NULL,
    entidad_id INT NULL,
    descripcion TEXT NULL,
    datos_anteriores JSON NULL,
    datos_nuevos JSON NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(500) NULL,
    fecha_accion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_admin (admin_id),
    INDEX idx_tipo_accion (tipo_accion),
    INDEX idx_fecha (fecha_accion),
    INDEX idx_entidad (entidad_afectada, entidad_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de configuraciones del sistema
CREATE TABLE IF NOT EXISTS configuraciones (
    id INT PRIMARY KEY AUTO_INCREMENT,
    clave VARCHAR(100) NOT NULL UNIQUE,
    valor TEXT NULL,
    tipo ENUM('texto', 'numero', 'booleano', 'json') DEFAULT 'texto',
    descripcion TEXT NULL,
    categoria VARCHAR(50) NULL,
    editable BOOLEAN DEFAULT TRUE,
    fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_clave (clave),
    INDEX idx_categoria (categoria)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de notificaciones para usuarios
CREATE TABLE IF NOT EXISTS notificaciones (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NULL,
    tipo ENUM('info', 'success', 'warning', 'error', 'system') DEFAULT 'info',
    titulo VARCHAR(255) NOT NULL,
    mensaje TEXT NOT NULL,
    enlace VARCHAR(500) NULL,
    leida BOOLEAN DEFAULT FALSE,
    fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_leida DATETIME NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_usuario (usuario_id),
    INDEX idx_leida (leida),
    INDEX idx_fecha (fecha_creacion),
    INDEX idx_tipo (tipo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de reportes generados
CREATE TABLE IF NOT EXISTS reportes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    nombre VARCHAR(255) NOT NULL,
    tipo_reporte VARCHAR(50) NOT NULL,
    parametros JSON NULL,
    datos JSON NULL,
    formato ENUM('json', 'csv', 'pdf', 'xlsx') DEFAULT 'json',
    ruta_archivo VARCHAR(500) NULL,
    fecha_generacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_desde DATE NULL,
    fecha_hasta DATE NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_usuario (usuario_id),
    INDEX idx_tipo (tipo_reporte),
    INDEX idx_fecha (fecha_generacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Vista de logs de administración con información del admin
CREATE OR REPLACE VIEW vista_logs_admin AS
SELECT 
    l.id,
    l.admin_id,
    l.tipo_accion,
    l.entidad_afectada,
    l.entidad_id,
    l.descripcion,
    l.fecha_accion,
    l.ip_address,
    u.nombre AS admin_nombre,
    u.email AS admin_email,
    u.rol AS admin_rol
FROM logs_admin l
INNER JOIN usuarios u ON l.admin_id = u.id
ORDER BY l.fecha_accion DESC;

-- Vista de notificaciones con información del usuario
CREATE OR REPLACE VIEW vista_notificaciones AS
SELECT 
    n.id,
    n.usuario_id,
    n.tipo,
    n.titulo,
    n.mensaje,
    n.enlace,
    n.leida,
    n.fecha_creacion,
    n.fecha_leida,
    u.nombre AS usuario_nombre,
    u.email AS usuario_email
FROM notificaciones n
LEFT JOIN usuarios u ON n.usuario_id = u.id
ORDER BY n.fecha_creacion DESC;

-- Insertar algunas configuraciones iniciales
INSERT INTO configuraciones (clave, valor, tipo, descripcion, categoria) VALUES
('sistema_nombre', 'Contraloría Social Tamaulipas', 'texto', 'Nombre del sistema', 'general'),
('sistema_version', '1.0.0', 'texto', 'Versión del sistema', 'general'),
('registros_por_pagina', '25', 'numero', 'Número de registros por página', 'general'),
('notificaciones_activas', 'true', 'booleano', 'Activar sistema de notificaciones', 'notificaciones'),
('mantenimiento', 'false', 'booleano', 'Modo de mantenimiento', 'sistema')
ON DUPLICATE KEY UPDATE valor = valor;

-- Mensaje de confirmación
SELECT 'Tablas de administración creadas exitosamente' AS resultado;


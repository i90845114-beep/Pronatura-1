<?php
require_once __DIR__ . '/../api/db_connection.php';

header('Content-Type: text/html; charset=utf-8');

try {
    $conn = getDB();
    
    echo "<h2>Crear Usuario Administrador</h2>";
    
    // Si se envió el formulario
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = trim($_POST['email'] ?? '');
        $action = $_POST['action'] ?? '';
        
        if (empty($email)) {
            echo "<p style='color: red;'>❌ Por favor ingresa un email</p>";
        } else {
            $email = strtolower($email);
            
            if ($action === 'make_admin') {
                // Convertir usuario a admin
                $stmt = $conn->prepare("UPDATE usuarios SET rol = 'admin' WHERE email = ?");
                $stmt->execute([$email]);
                
                if ($stmt->rowCount() > 0) {
                    echo "<p style='color: green;'>✅ Usuario convertido a administrador exitosamente</p>";
                } else {
                    echo "<p style='color: orange;'>⚠️ No se encontró un usuario con ese email</p>";
                }
            } elseif ($action === 'remove_admin') {
                // Quitar rol de admin
                $stmt = $conn->prepare("UPDATE usuarios SET rol = 'usuario' WHERE email = ?");
                $stmt->execute([$email]);
                
                if ($stmt->rowCount() > 0) {
                    echo "<p style='color: green;'>✅ Rol de administrador removido exitosamente</p>";
                } else {
                    echo "<p style='color: orange;'>⚠️ No se encontró un usuario con ese email</p>";
                }
            }
        }
    }
    
    // Mostrar lista de usuarios
    echo "<h3>Usuarios en el sistema:</h3>";
    $stmt = $conn->query("SELECT id, nombre, email, rol, activo FROM usuarios ORDER BY fecha_registro DESC");
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($usuarios)) {
        echo "<p>No hay usuarios registrados</p>";
    } else {
        echo "<table border='1' cellpadding='10' cellspacing='0' style='border-collapse: collapse; width: 100%; margin-bottom: 2rem;'>";
        echo "<tr style='background: #2c7a7b; color: white;'>";
        echo "<th>ID</th><th>Nombre</th><th>Email</th><th>Rol</th><th>Estado</th>";
        echo "</tr>";
        
        foreach ($usuarios as $user) {
            $rolColor = $user['rol'] === 'admin' ? 'background: #cfe2ff; color: #084298;' : 'background: #e2e3e5; color: #41464b;';
            $activoColor = $user['activo'] ? 'background: #d4edda; color: #155724;' : 'background: #f8d7da; color: #721c24;';
            
            echo "<tr>";
            echo "<td>{$user['id']}</td>";
            echo "<td>{$user['nombre']}</td>";
            echo "<td><strong>{$user['email']}</strong></td>";
            echo "<td><span style='padding: 0.25rem 0.75rem; border-radius: 12px; font-size: 0.85rem; {$rolColor}'>{$user['rol']}</span></td>";
            echo "<td><span style='padding: 0.25rem 0.75rem; border-radius: 12px; font-size: 0.85rem; {$activoColor}'>" . ($user['activo'] ? 'Activo' : 'Inactivo') . "</span></td>";
            echo "</tr>";
        }
        
        echo "</table>";
    }
    
    // Formulario para convertir usuario
    echo "<hr>";
    echo "<h3>Convertir Usuario a Administrador</h3>";
    echo "<form method='POST' style='background: #f9f9f9; padding: 1.5rem; border-radius: 8px; max-width: 500px;'>";
    echo "<div style='margin-bottom: 1rem;'>";
    echo "<label style='display: block; margin-bottom: 0.5rem; font-weight: 600;'>Email del usuario:</label>";
    echo "<input type='email' name='email' required style='width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 6px; font-size: 1rem;'>";
    echo "</div>";
    echo "<div style='display: flex; gap: 1rem;'>";
    echo "<button type='submit' name='action' value='make_admin' style='flex: 1; padding: 0.75rem; background: #2c7a7b; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 1rem; font-weight: 600;'>Hacer Administrador</button>";
    echo "<button type='submit' name='action' value='remove_admin' style='flex: 1; padding: 0.75rem; background: #dc3545; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 1rem; font-weight: 600;'>Quitar Admin</button>";
    echo "</div>";
    echo "</form>";
    
    echo "<hr>";
    echo "<h3>📝 Instrucciones:</h3>";
    echo "<ol style='line-height: 2;'>";
    echo "<li>Busca tu email en la tabla de arriba</li>";
    echo "<li>Copia tu email y pégalo en el formulario</li>";
    echo "<li>Haz clic en 'Hacer Administrador'</li>";
    echo "<li>Una vez convertido, puedes acceder al panel en: <a href='../pages/admin.html' target='_blank'><strong>pages/admin.html</strong></a></li>";
    echo "</ol>";
    
    echo "<p style='background: #fff3cd; padding: 1rem; border-radius: 6px; border-left: 4px solid #ffc107; margin-top: 1rem;'>";
    echo "<strong>⚠️ Importante:</strong> Asegúrate de estar logueado con ese email antes de acceder al panel de administración.";
    echo "</p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>


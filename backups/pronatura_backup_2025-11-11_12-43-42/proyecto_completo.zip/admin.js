// Panel de Administración
let allUsers = [];
let allRegistros = [];
let allCategorias = [];
let allComentarios = [];

// Verificar que el usuario es administrador
document.addEventListener('DOMContentLoaded', async () => {
    // Cargar el sistema de autenticación de admin
    if (typeof window.adminAuthSystem === 'undefined') {
        // Si no está cargado, cargarlo dinámicamente
        const script = document.createElement('script');
        script.src = '../assets/js/admin-auth.js';
        script.onload = () => {
            checkAdminAccess();
        };
        document.head.appendChild(script);
    } else {
        checkAdminAccess();
    }
});

async function checkAdminAccess() {
    // Verificar autenticación de administrador
    if (!window.adminAuthSystem || !window.adminAuthSystem.isAuthenticated()) {
        alert('Debes iniciar sesión como administrador para acceder a este panel');
        window.location.href = 'admin-login.html';
        return false;
    }
    
    // Verificar token con el servidor
    const token = window.adminAuthSystem.getToken();
    try {
        const response = await fetch(`../api/api.php?action=verify_admin_session&token=${token}`);
        const data = await response.json();
        
        if (!data.success) {
            alert('Tu sesión de administrador ha expirado. Por favor, inicia sesión nuevamente.');
            window.adminAuthSystem.logout();
            window.location.href = 'admin-login.html';
            return false;
        }
    } catch (error) {
        console.error('Error al verificar sesión:', error);
        alert('Error al verificar tu sesión. Por favor, intenta nuevamente.');
        window.location.href = 'admin-login.html';
        return false;
    }
    
    // Mostrar nombre de administrador
    const admin = window.adminAuthSystem.getCurrentAdmin();
    const userNameEl = document.getElementById('userName');
    if (userNameEl && admin) {
        userNameEl.textContent = admin.nombre;
    }
    
    // Inicializar el panel
    initializeAdmin();
    return true;
}

function initializeAdmin() {
    setupTabNavigation();
    
    // Limpiar marcador de edición cuando se regresa al panel
    sessionStorage.removeItem('editingFromAdmin');
    sessionStorage.removeItem('editingRecord');
    
    // Verificar si hay hash en la URL para activar una pestaña específica
    const hash = window.location.hash.replace('#', '');
    if (hash) {
        // Activar la pestaña especificada en el hash
        const targetTab = document.querySelector(`[data-tab="${hash}"]`);
        if (targetTab) {
            targetTab.click();
        } else {
            // Si no se encuentra, cargar dashboard por defecto
            loadDashboard();
        }
    } else {
        loadDashboard();
    }
    
    setupEventListeners();
    // Cargar categorías al inicializar para que estén disponibles en los filtros
    loadCategorias();
}

function setupTabNavigation() {
    const tabs = document.querySelectorAll('.nav-tab');
    const sections = document.querySelectorAll('.admin-section');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetTab = tab.dataset.tab;
            
            // Remover active de todos
            tabs.forEach(t => t.classList.remove('active'));
            sections.forEach(s => s.classList.remove('active'));
            
            // Agregar active al seleccionado
            tab.classList.add('active');
            const targetSection = document.getElementById(targetTab);
            if (targetSection) {
                targetSection.classList.add('active');
                
                // Cargar contenido según la pestaña
                switch(targetTab) {
                    case 'dashboard':
                        loadDashboard();
                        break;
                    case 'usuarios':
                        loadUsuarios();
                        break;
                    case 'registros':
                        loadAllRegistros();
                        // Cargar categorías para el filtro si no están cargadas
                        if (!allCategorias || allCategorias.length === 0) {
                            loadCategorias();
                        }
                        break;
                    case 'categorias':
                        loadCategorias();
                        break;
                    case 'comentarios':
                        loadComentarios();
                        break;
                }
            }
        });
    });
}

function setupEventListeners() {
    // Formularios
    const editUserForm = document.getElementById('editUserForm');
    if (editUserForm) {
        editUserForm.addEventListener('submit', handleEditUser);
    }
    
    const addUserForm = document.getElementById('addUserForm');
    if (addUserForm) {
        addUserForm.addEventListener('submit', handleAddUser);
    }
    
    // Filtros
    const searchUsers = document.getElementById('searchUsers');
    if (searchUsers) {
        searchUsers.addEventListener('input', filterUsuarios);
    }
    
    const filterRol = document.getElementById('filterRol');
    if (filterRol) {
        filterRol.addEventListener('change', filterUsuarios);
    }
    
    const filterActivo = document.getElementById('filterActivo');
    if (filterActivo) {
        filterActivo.addEventListener('change', filterUsuarios);
    }
    
    // Filtros de registros
    const searchRegistros = document.getElementById('searchRegistros');
    if (searchRegistros) {
        searchRegistros.addEventListener('input', filterRegistros);
        // También buscar al presionar Enter
        searchRegistros.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                if (searchTimeout) clearTimeout(searchTimeout);
                loadAllRegistros();
            }
        });
    }
    
    const filterCategoriaAdmin = document.getElementById('filterCategoriaAdmin');
    if (filterCategoriaAdmin) {
        filterCategoriaAdmin.addEventListener('change', () => {
            loadAllRegistros();
        });
    }
    
    const filterUsuarioAdmin = document.getElementById('filterUsuarioAdmin');
    if (filterUsuarioAdmin) {
        filterUsuarioAdmin.addEventListener('change', () => {
            loadAllRegistros();
        });
    }
    
    // Filtros de comentarios
    const searchComentarios = document.getElementById('searchComentarios');
    if (searchComentarios) {
        searchComentarios.addEventListener('input', filterComentarios);
    }
    
    const filterComentarioActivo = document.getElementById('filterComentarioActivo');
    if (filterComentarioActivo) {
        filterComentarioActivo.addEventListener('change', filterComentarios);
    }
    
    // Botón de preview de gráficas con datos de ejemplo
    const btnPreviewCharts = document.getElementById('btnPreviewCharts');
    if (btnPreviewCharts) {
        btnPreviewCharts.addEventListener('click', previewChartsWithSampleData);
    }
}

// ==================== DASHBOARD ====================
async function loadDashboard() {
    try {
        const [stats, categoriasData] = await Promise.all([
            fetch('../api/api.php?action=get_admin_stats'),
            fetch('../api/api.php?action=get_categorias')
        ]);
        
        const statsData = await stats.json();
        const categorias = await categoriasData.json();
        
        if (statsData.success) {
            document.getElementById('statUsuarios').textContent = statsData.stats.total_usuarios || 0;
            document.getElementById('statRegistros').textContent = statsData.stats.total_registros || 0;
            document.getElementById('statCategorias').textContent = categorias.success ? categorias.categorias.length : 0;
            document.getElementById('statComentarios').textContent = statsData.stats.total_comentarios || 0;
        }
        
        // Cargar gráficos
        loadCharts(statsData.stats);
    } catch (error) {
        console.error('Error al cargar dashboard:', error);
    }
}

async function loadCharts(stats) {
    try {
        // Obtener datos para los gráficos
        const response = await fetch('../api/api.php?action=get_all_registros');
        const data = await response.json();
        
        if (data.success && data.records) {
            const registros = data.records;
            
            // Gráfico de registros por categoría
            renderChartCategorias(registros);
            
            // Gráfico de registros por mes
            renderChartMeses(registros);
        } else {
            document.getElementById('chartCategorias').innerHTML = '<p style="color: #999; text-align: center; padding: 2rem;">No hay datos disponibles</p>';
            document.getElementById('chartMeses').innerHTML = '<p style="color: #999; text-align: center; padding: 2rem;">No hay datos disponibles</p>';
        }
    } catch (error) {
        console.error('Error al cargar gráficos:', error);
        document.getElementById('chartCategorias').innerHTML = '<p style="color: #d32f2f; text-align: center; padding: 2rem;">Error al cargar gráfico</p>';
        document.getElementById('chartMeses').innerHTML = '<p style="color: #d32f2f; text-align: center; padding: 2rem;">Error al cargar gráfico</p>';
    }
}

// Función para generar datos de ejemplo (SOLO PARA VISUALIZACIÓN)
function generateSampleData() {
    // Categorías de ejemplo
    const categoriasEjemplo = [
        'Gestión Administrativa y Organizativa',
        'Conservación de Ecosistemas',
        'Educación Ambiental',
        'Investigación Científica',
        'Manejo de Recursos Naturales',
        'Monitoreo y Evaluación',
        'Participación Comunitaria',
        'Restauración Ecológica'
    ];
    
    // Generar registros de ejemplo por categoría
    const registrosEjemplo = [];
    
    categoriasEjemplo.forEach((categoria, index) => {
        const cantidad = Math.floor(Math.random() * 50) + 10; // Entre 10 y 60 registros
        
        for (let i = 0; i < cantidad; i++) {
            // Generar fecha aleatoria en los últimos 12 meses
            const mesesAtras = Math.floor(Math.random() * 12);
            const fecha = new Date();
            fecha.setMonth(fecha.getMonth() - mesesAtras);
            fecha.setDate(Math.floor(Math.random() * 28) + 1); // Día aleatorio del mes
            
            registrosEjemplo.push({
                id: i + 1,
                categoria_nombre: categoria,
                fecha: fecha.toISOString().split('T')[0],
                fecha_creacion: fecha.toISOString()
            });
        }
    });
    
    return registrosEjemplo;
}

// Función para mostrar gráficas con datos de ejemplo
function previewChartsWithSampleData() {
    console.log('📊 Generando datos de ejemplo para visualización...');
    
    const sampleData = generateSampleData();
    
    // Renderizar gráficas con datos de ejemplo
    renderChartCategorias(sampleData);
    renderChartMeses(sampleData);
    
    // Mostrar mensaje informativo
    const message = document.createElement('div');
    message.style.cssText = 'position: fixed; top: 20px; right: 20px; background: linear-gradient(135deg, #805ad5 0%, #9f7aea 100%); color: white; padding: 1rem 1.5rem; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.2); z-index: 10000; font-weight: 600; max-width: 300px;';
    message.innerHTML = '📊 <strong>Vista previa</strong><br><small style="opacity: 0.9;">Datos de ejemplo - No se guardó nada</small>';
    
    document.body.appendChild(message);
    
    // Remover mensaje después de 4 segundos
    setTimeout(() => {
        message.style.transition = 'opacity 0.5s ease';
        message.style.opacity = '0';
        setTimeout(() => message.remove(), 500);
    }, 4000);
    
    // Cambiar texto del botón temporalmente
    const btn = document.getElementById('btnPreviewCharts');
    const originalText = btn.innerHTML;
    btn.innerHTML = '✅ Datos de Ejemplo Cargados';
    btn.style.background = 'linear-gradient(135deg, #38a169 0%, #48bb78 100%)';
    
    setTimeout(() => {
        btn.innerHTML = originalText;
        btn.style.background = 'linear-gradient(135deg, #805ad5 0%, #9f7aea 100%)';
    }, 3000);
}

function renderChartCategorias(registros) {
    const container = document.getElementById('chartCategorias');
    if (!container) return;
    
    // Contar registros por categoría
    const categoriasCount = {};
    registros.forEach(reg => {
        const catNombre = reg.categoria_nombre || 'Sin categoría';
        categoriasCount[catNombre] = (categoriasCount[catNombre] || 0) + 1;
    });
    
    // Ordenar por cantidad (descendente) - mostrar todas
    const sortedCategorias = Object.entries(categoriasCount)
        .sort((a, b) => b[1] - a[1]);
    
    if (sortedCategorias.length === 0) {
        container.innerHTML = '<div style="display: flex; align-items: center; justify-content: center; height: 400px; color: #999;"><p>No hay registros por categoría</p></div>';
        return;
    }
    
    const maxValue = Math.max(...sortedCategorias.map(([_, count]) => count));
    const total = sortedCategorias.reduce((sum, [_, count]) => sum + count, 0);
    
    // Colores profesionales
    const colors = [
        { gradient: 'linear-gradient(180deg, #2c7a7b 0%, #38a169 100%)', solid: '#2c7a7b', light: '#e6fffa' },
        { gradient: 'linear-gradient(180deg, #3182ce 0%, #4299e1 100%)', solid: '#3182ce', light: '#ebf8ff' },
        { gradient: 'linear-gradient(180deg, #805ad5 0%, #9f7aea 100%)', solid: '#805ad5', light: '#faf5ff' },
        { gradient: 'linear-gradient(180deg, #d69e2e 0%, #f6ad55 100%)', solid: '#d69e2e', light: '#fffaf0' },
        { gradient: 'linear-gradient(180deg, #e53e3e 0%, #fc8181 100%)', solid: '#e53e3e', light: '#fff5f5' },
        { gradient: 'linear-gradient(180deg, #dd6b20 0%, #f6ad55 100%)', solid: '#dd6b20', light: '#fffaf0' },
        { gradient: 'linear-gradient(180deg, #319795 0%, #4fd1c7 100%)', solid: '#319795', light: '#e6fffa' },
        { gradient: 'linear-gradient(180deg, #0987a0 0%, #0bc5ea 100%)', solid: '#0987a0', light: '#e6fffa' }
    ];
    
    // Altura máxima del gráfico
    const chartHeight = 300;
    // Ancho fijo para todas las barras - todas iguales
    const barWidth = 60; // Ancho fijo para todas las barras
    
    let html = `
        <div style="padding: 0; width: 100%; box-sizing: border-box;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.25rem;">
                <div>
                    <p style="margin: 0; color: #718096; font-size: 0.85rem; font-weight: 500;">Total de registros: <strong style="color: #2d3748;">${total}</strong></p>
                </div>
            </div>
            <!-- Gráfico de barras verticales -->
            <div style="background: #f7fafc; border-radius: 12px; padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: inset 0 2px 8px rgba(0,0,0,0.05); overflow: hidden; width: 100%; box-sizing: border-box;">
                <div style="display: flex; align-items: flex-end; justify-content: space-between; height: ${chartHeight}px; position: relative; padding: 0; width: 100%;">
                    <!-- Línea base visible para alinear todas las barras -->
                    <div style="position: absolute; bottom: 0; left: 0; right: 0; height: 3px; background: #4a5568; z-index: 1; box-shadow: 0 1px 2px rgba(0,0,0,0.1);"></div>
    `;
    
    sortedCategorias.forEach(([nombre, count], index) => {
        const percentage = maxValue > 0 ? (count / maxValue) * 100 : 0;
        const barHeight = Math.max(20, (percentage / 100) * (chartHeight - 100)); // Altura mínima de 20px, ajustada para la línea base
        const color = colors[index % colors.length];
        // Mostrar nombres completos con saltos de línea automáticos - sin truncar
        const nombreDisplay = escapeHtml(nombre);
        
        html += `
            <div style="display: flex; flex-direction: column; align-items: center; justify-content: flex-end; position: relative; z-index: 2; height: ${chartHeight}px; flex: 1; min-width: 0; padding: 0 0.25rem; box-sizing: border-box;" 
                 onmouseover="const tip = this.querySelector('.bar-tooltip'); const bar = this.querySelector('.bar'); if(tip) tip.style.display='block'; if(bar) bar.style.transform='scaleY(1.05)';" 
                 onmouseout="const tip = this.querySelector('.bar-tooltip'); const bar = this.querySelector('.bar'); if(tip) tip.style.display='none'; if(bar) bar.style.transform='scaleY(1)';">
                <!-- Tooltip -->
                <div class="bar-tooltip" style="position: absolute; bottom: ${barHeight + 50}px; left: 50%; transform: translateX(-50%); background: #1a202c; color: white; padding: 0.5rem 0.75rem; border-radius: 8px; font-size: 0.85rem; font-weight: 600; white-space: nowrap; box-shadow: 0 4px 12px rgba(0,0,0,0.3); display: none; z-index: 10; pointer-events: none; max-width: 200px; overflow: hidden; text-overflow: ellipsis;">
                    <div style="text-align: center;">
                        <div style="font-size: 1.2rem; font-weight: 700; margin-bottom: 0.25rem;">${count}</div>
                        <div style="font-size: 0.75rem; opacity: 0.9; white-space: normal; word-wrap: break-word; max-width: 180px;">${escapeHtml(nombre)}</div>
                    </div>
                    <div style="position: absolute; bottom: -6px; left: 50%; transform: translateX(-50%); width: 0; height: 0; border-left: 6px solid transparent; border-right: 6px solid transparent; border-top: 6px solid #1a202c;"></div>
                </div>
                
                <!-- Número sobre la barra -->
                <div style="position: absolute; bottom: ${barHeight + 25}px; left: 50%; transform: translateX(-50%); font-size: 0.85rem; font-weight: 700; color: ${color.solid}; white-space: nowrap; z-index: 3; text-shadow: 0 1px 2px rgba(255,255,255,0.8);">${count}</div>
                
                <!-- Barra -->
                <div class="bar" style="width: ${barWidth}px; height: ${barHeight}px; min-height: 20px; background: ${color.gradient}; border-radius: 8px 8px 0 0; margin-bottom: 0; transition: all 0.3s ease; box-shadow: 0 4px 12px rgba(0,0,0,0.15); position: relative; cursor: pointer; flex-shrink: 0; align-self: flex-end;">
                </div>
                
                <!-- Etiqueta -->
                <div style="font-size: 0.7rem; color: #718096; text-align: center; font-weight: 600; line-height: 1.2; width: 100%; word-wrap: break-word; margin-top: 0.1rem; padding: 0; cursor: help; white-space: normal; overflow-wrap: break-word; hyphens: auto; box-sizing: border-box;" title="${escapeHtml(nombre)}">
                    ${nombreDisplay}
                </div>
            </div>
        `;
    });
    
    html += `
                </div>
            </div>
            
            <!-- Leyenda detallada -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; width: 100%; box-sizing: border-box;">
    `;
    
    sortedCategorias.forEach(([nombre, count], index) => {
        const percentageOfTotal = total > 0 ? ((count / total) * 100).toFixed(1) : 0;
        const color = colors[index % colors.length];
        
        html += `
            <div style="display: flex; align-items: center; gap: 1rem; padding: 1rem; background: white; border-radius: 8px; border-left: 4px solid ${color.solid}; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <div style="width: 12px; height: 12px; background: ${color.gradient}; border-radius: 3px; flex-shrink: 0;"></div>
                <div style="flex: 1; min-width: 0;">
                    <div style="font-weight: 600; color: #2d3748; font-size: 0.9rem; margin-bottom: 0.25rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${escapeHtml(nombre)}">
                        ${escapeHtml(nombre.length > 30 ? nombre.substring(0, 27) + '...' : nombre)}
                    </div>
                    <div style="font-size: 0.8rem; color: #718096;">
                        ${count} ${count === 1 ? 'registro' : 'registros'} • ${percentageOfTotal}%
                    </div>
                </div>
            </div>
        `;
    });
    
    html += `
            </div>
        </div>
    `;
    
    container.innerHTML = html;
}

function renderChartMeses(registros) {
    const container = document.getElementById('chartMeses');
    if (!container) return;
    
    // Contar registros por mes
    const mesesCount = {};
    const mesesNombres = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    const mesesCortos = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    
    registros.forEach(reg => {
        if (reg.fecha || reg.fecha_creacion) {
            const fecha = new Date(reg.fecha || reg.fecha_creacion);
            if (!isNaN(fecha.getTime())) {
                const mes = fecha.getMonth(); // 0-11
                const año = fecha.getFullYear();
                const key = `${año}-${String(mes + 1).padStart(2, '0')}`;
                const label = `${mesesCortos[mes]} ${año}`;
                const labelCompleto = `${mesesNombres[mes]} ${año}`;
                
                if (!mesesCount[key]) {
                    mesesCount[key] = { label, labelCompleto, count: 0, mes, año };
                }
                mesesCount[key].count++;
            }
        }
    });
    
    // Ordenar por fecha (ascendente) y tomar últimos 12 meses
    const sortedMeses = Object.entries(mesesCount)
        .sort(([a], [b]) => a.localeCompare(b))
        .slice(-12); // Últimos 12 meses
    
    if (sortedMeses.length === 0) {
        container.innerHTML = '<div style="display: flex; align-items: center; justify-content: center; height: 400px; color: #999;"><p>No hay registros por mes</p></div>';
        return;
    }
    
    const maxValue = Math.max(...sortedMeses.map(([_, data]) => data.count));
    const total = sortedMeses.reduce((sum, [_, data]) => sum + data.count, 0);
    
    // Colores con gradiente teal
    const gradientColor = 'linear-gradient(180deg, #2c7a7b 0%, #38a169 100%)';
    const solidColor = '#2c7a7b';
    
    // Altura máxima del gráfico
    const chartHeight = 300;
    const barWidth = Math.max(30, (100 / sortedMeses.length) - 1.5); // Ancho dinámico
    const spacing = 5;
    
    let html = `
        <div style="padding: 0; width: 100%; box-sizing: border-box;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <div>
                    <p style="margin: 0; color: #718096; font-size: 0.85rem; font-weight: 500;">Total de registros: <strong style="color: #2d3748;">${total}</strong></p>
                </div>
            </div>
            <!-- Gráfico de barras verticales -->
            <div style="background: #f7fafc; border-radius: 12px; padding: 1.5rem 1.5rem 1.5rem 3rem; margin-bottom: 1.5rem; box-shadow: inset 0 2px 8px rgba(0,0,0,0.05); position: relative; overflow: hidden; width: 100%; box-sizing: border-box;">
                <div style="display: flex; align-items: flex-end; justify-content: space-around; height: ${chartHeight}px; position: relative; padding: 0 1rem;">
                    <!-- Línea de fondo para escala -->
                    <div style="position: absolute; bottom: 0; left: 0; right: 0; height: 2px; background: #cbd5e0; z-index: 1;"></div>
                    
                    <!-- Líneas de referencia horizontales y etiquetas del eje Y -->
                    ${maxValue > 0 ? Array.from({length: 5}, (_, i) => {
                        // i=0 es el valor máximo (arriba), i=4 es 0 (abajo)
                        const value = Math.ceil((maxValue / 4) * (4 - i));
                        // Calcular posición desde abajo: i=0 está arriba (chartHeight-80), i=4 está abajo (0)
                        const yPos = ((4 - i) / 4) * (chartHeight - 80);
                        return `
                            <div style="position: absolute; left: 0; right: 0; bottom: ${yPos}px; height: 1px; background: #e2e8f0; z-index: 1; opacity: 0.5;"></div>
                            <div style="position: absolute; left: -2.5rem; bottom: ${yPos}px; margin-bottom: -0.5px; font-size: 0.75rem; color: #a0aec0; font-weight: 600; width: 40px; text-align: right; line-height: 0.75rem; height: 0.75rem; z-index: 2; display: flex; align-items: center; justify-content: flex-end;">${value}</div>
                        `;
                    }).join('') : ''}
    `;
    
    sortedMeses.forEach(([_, data], index) => {
        const percentage = maxValue > 0 ? (data.count / maxValue) * 100 : 0;
        const barHeight = Math.max(20, (percentage / 100) * (chartHeight - 80)); // Altura mínima de 20px
        
        html += `
            <div style="flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; margin: 0 ${spacing}px; position: relative; z-index: 2; height: ${chartHeight}px;" 
                 onmouseover="const tip = this.querySelector('.bar-tooltip'); const bar = this.querySelector('.bar'); if(tip) tip.style.display='block'; if(bar) bar.style.transform='scaleY(1.05)';" 
                 onmouseout="const tip = this.querySelector('.bar-tooltip'); const bar = this.querySelector('.bar'); if(tip) tip.style.display='none'; if(bar) bar.style.transform='scaleY(1)';">
                <!-- Tooltip -->
                <div class="bar-tooltip" style="position: absolute; bottom: ${barHeight + 50}px; left: 50%; transform: translateX(-50%); background: #1a202c; color: white; padding: 0.5rem 0.75rem; border-radius: 8px; font-size: 0.85rem; font-weight: 600; white-space: nowrap; box-shadow: 0 4px 12px rgba(0,0,0,0.3); display: none; z-index: 10; pointer-events: none;">
                    <div style="text-align: center;">
                        <div style="font-size: 1.2rem; font-weight: 700; margin-bottom: 0.25rem;">${data.count}</div>
                        <div style="font-size: 0.75rem; opacity: 0.9;">${escapeHtml(data.labelCompleto)}</div>
                    </div>
                    <div style="position: absolute; bottom: -6px; left: 50%; transform: translateX(-50%); width: 0; height: 0; border-left: 6px solid transparent; border-right: 6px solid transparent; border-top: 6px solid #1a202c;"></div>
                </div>
                
                <!-- Número sobre la barra -->
                <div style="position: absolute; bottom: ${barHeight + 25}px; left: 50%; transform: translateX(-50%); font-size: 0.85rem; font-weight: 700; color: ${solidColor}; white-space: nowrap; z-index: 3; text-shadow: 0 1px 2px rgba(255,255,255,0.8);">${data.count}</div>
                
                <!-- Barra -->
                <div class="bar" style="width: ${barWidth}%; max-width: 50px; min-width: 25px; height: ${barHeight}px; min-height: 20px; background: ${gradientColor}; border-radius: 8px 8px 0 0; margin-bottom: 0.5rem; transition: all 0.3s ease; box-shadow: 0 4px 12px rgba(44, 122, 123, 0.25); position: relative; cursor: pointer;">
                </div>
                
                <!-- Etiqueta -->
                <div style="font-size: 0.7rem; color: #718096; text-align: center; font-weight: 600; line-height: 1.2; max-width: 70px; word-wrap: break-word; margin-top: 0.25rem;" title="${escapeHtml(data.labelCompleto)}">
                    ${escapeHtml(data.label)}
                </div>
            </div>
        `;
    });
    
    html += `
                </div>
            </div>
            
            <!-- Resumen de meses -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 0.75rem; width: 100%; box-sizing: border-box;">
    `;
    
    sortedMeses.forEach(([_, data], index) => {
        const percentageOfTotal = total > 0 ? ((data.count / total) * 100).toFixed(1) : 0;
        
        html += `
            <div style="display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem; background: white; border-radius: 8px; border-left: 3px solid ${solidColor}; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                <div style="width: 8px; height: 8px; background: ${gradientColor}; border-radius: 50%; flex-shrink: 0;"></div>
                <div style="flex: 1; min-width: 0;">
                    <div style="font-weight: 600; color: #2d3748; font-size: 0.85rem; margin-bottom: 0.15rem;">
                        ${escapeHtml(data.labelCompleto)}
                    </div>
                    <div style="font-size: 0.75rem; color: #718096;">
                        ${data.count} ${data.count === 1 ? 'registro' : 'registros'} • ${percentageOfTotal}%
                    </div>
                </div>
            </div>
        `;
    });
    
    html += `
            </div>
        </div>
    `;
    
    container.innerHTML = html;
}

// ==================== USUARIOS ====================
async function loadUsuarios() {
    try {
        const response = await fetch('../api/api.php?action=get_all_usuarios');
        const data = await response.json();
        
        if (data.success) {
            allUsers = data.usuarios;
            renderUsuarios(allUsers);
            populateUserFilter();
        } else {
            document.getElementById('usuariosTableBody').innerHTML = 
                '<tr><td colspan="8" class="loading">Error al cargar usuarios</td></tr>';
        }
    } catch (error) {
        console.error('Error al cargar usuarios:', error);
        document.getElementById('usuariosTableBody').innerHTML = 
            '<tr><td colspan="8" class="loading">Error de conexión</td></tr>';
    }
}

function renderUsuarios(usuarios) {
    const tbody = document.getElementById('usuariosTableBody');
    
    if (usuarios.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="loading">No hay usuarios</td></tr>';
        return;
    }
    
    tbody.innerHTML = usuarios.map(user => `
        <tr>
            <td>${user.id}</td>
            <td>${escapeHtml(user.nombre)}</td>
            <td>${escapeHtml(user.email)}</td>
            <td><span class="badge ${user.rol === 'admin' ? 'badge-primary' : 'badge-secondary'}">${user.rol}</span></td>
            <td><span class="badge ${user.activo ? 'badge-success' : 'badge-danger'}">${user.activo ? 'Activo' : 'Inactivo'}</span></td>
            <td>${formatDate(user.fecha_registro)}</td>
            <td>${user.fecha_ultimo_acceso ? formatDate(user.fecha_ultimo_acceso) : 'Nunca'}</td>
            <td class="action-buttons">
                <button class="btn-icon edit" onclick="editUser(${user.id})" title="Editar">✏️</button>
                ${user.activo ? 
                    `<button class="btn-icon delete" onclick="toggleUserStatus(${user.id}, false)" title="Desactivar">🚫</button>` :
                    `<button class="btn-icon activate" onclick="toggleUserStatus(${user.id}, true)" title="Activar">✅</button>`
                }
                ${user.rol !== 'admin' ? 
                    `<button class="btn-icon delete" onclick="deleteUser(${user.id})" title="Eliminar">🗑️</button>` : ''
                }
            </td>
        </tr>
    `).join('');
}

function filterUsuarios() {
    const search = document.getElementById('searchUsers').value.toLowerCase();
    const rol = document.getElementById('filterRol').value;
    const activo = document.getElementById('filterActivo').value;
    
    let filtered = allUsers.filter(user => {
        const matchSearch = !search || 
            user.nombre.toLowerCase().includes(search) ||
            user.email.toLowerCase().includes(search);
        const matchRol = !rol || user.rol === rol;
        const matchActivo = activo === '' || (user.activo == activo);
        
        return matchSearch && matchRol && matchActivo;
    });
    
    renderUsuarios(filtered);
}

function populateUserFilter() {
    const select = document.getElementById('filterUsuarioAdmin');
    if (!select) return;
    
    select.innerHTML = '<option value="">Todos los usuarios</option>';
    allUsers.forEach(user => {
        const option = document.createElement('option');
        option.value = user.id;
        option.textContent = `${user.nombre} (${user.email})`;
        select.appendChild(option);
    });
}

async function editUser(userId) {
    const user = allUsers.find(u => u.id == userId);
    if (!user) return;
    
    document.getElementById('editUserId').value = user.id;
    document.getElementById('editUserName').value = user.nombre;
    document.getElementById('editUserEmail').value = user.email;
    document.getElementById('editUserRol').value = user.rol;
    document.getElementById('editUserActivo').value = user.activo ? '1' : '0';
    document.getElementById('editUserPassword').value = '';
    
    openModal('editUserModal');
}

async function handleEditUser(e) {
    e.preventDefault();
    
    const currentUser = window.authSystem ? window.authSystem.getCurrentUser() : null;
    if (!currentUser) return;
    
    const userId = document.getElementById('editUserId').value;
    const nombre = document.getElementById('editUserName').value;
    const email = document.getElementById('editUserEmail').value;
    const rol = document.getElementById('editUserRol').value;
    const activo = document.getElementById('editUserActivo').value;
    const password = document.getElementById('editUserPassword').value;
    
    try {
        const response = await fetch('../api/api.php?action=update_usuario&current_user_id=' + currentUser.id, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                id: userId,
                nombre,
                email,
                rol,
                activo: activo === '1',
                password: password || null
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Usuario actualizado exitosamente');
            closeModal('editUserModal');
            loadUsuarios();
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al actualizar usuario');
    }
}

function showAddUserModal() {
    document.getElementById('addUserForm').reset();
    openModal('addUserModal');
}

async function handleAddUser(e) {
    e.preventDefault();
    
    const currentUser = window.authSystem ? window.authSystem.getCurrentUser() : null;
    if (!currentUser) return;
    
    const nombre = document.getElementById('addUserName').value;
    const email = document.getElementById('addUserEmail').value;
    const password = document.getElementById('addUserPassword').value;
    const rol = document.getElementById('addUserRol').value;
    
    try {
        const response = await fetch('../api/api.php?action=create_usuario&current_user_id=' + currentUser.id, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre, email, password, rol })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Usuario creado exitosamente');
            closeModal('addUserModal');
            loadUsuarios();
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al crear usuario');
    }
}

async function toggleUserStatus(userId, activo) {
    if (!confirm(`¿Estás seguro de ${activo ? 'activar' : 'desactivar'} este usuario?`)) {
        return;
    }
    
    const currentUser = window.authSystem ? window.authSystem.getCurrentUser() : null;
    if (!currentUser) return;
    
    try {
        const response = await fetch('../api/api.php?action=update_usuario&current_user_id=' + currentUser.id, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: userId, activo })
        });
        
        const data = await response.json();
        
        if (data.success) {
            loadUsuarios();
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al actualizar usuario');
    }
}

async function deleteUser(userId) {
    if (!confirm('¿Estás seguro de eliminar este usuario? Esta acción no se puede deshacer.')) {
        return;
    }
    
    const currentUser = window.authSystem ? window.authSystem.getCurrentUser() : null;
    if (!currentUser) return;
    
    try {
        const response = await fetch('../api/api.php?action=delete_usuario&current_user_id=' + currentUser.id, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: userId })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Usuario eliminado exitosamente');
            loadUsuarios();
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al eliminar usuario');
    }
}

// ==================== REGISTROS ====================
let searchTimeout = null;

async function loadAllRegistros() {
    const grid = document.getElementById('registrosGrid');
    if (!grid) return;
    
    grid.innerHTML = '<div class="loading-state">Cargando registros...</div>';
    
    try {
        // Construir URL con filtros
        const search = document.getElementById('searchRegistros')?.value.trim() || '';
        const categoriaId = document.getElementById('filterCategoriaAdmin')?.value || '';
        const usuarioId = document.getElementById('filterUsuarioAdmin')?.value || '';
        
        let url = '../api/api.php?action=get_all_registros';
        if (search) url += '&search=' + encodeURIComponent(search);
        if (categoriaId) url += '&categoria_id=' + encodeURIComponent(categoriaId);
        if (usuarioId) url += '&usuario_id=' + encodeURIComponent(usuarioId);
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            allRegistros = data.records || [];
            renderRegistros(allRegistros);
        } else {
            grid.innerHTML = '<div class="loading-state">Error al cargar registros: ' + (data.message || 'Error desconocido') + '</div>';
        }
    } catch (error) {
        console.error('Error al cargar registros:', error);
        const grid = document.getElementById('registrosGrid');
        if (grid) {
            grid.innerHTML = '<div class="loading-state">Error de conexión al cargar registros</div>';
        }
    }
}

function renderRegistros(registros) {
    const grid = document.getElementById('registrosGrid');
    if (!grid) return;
    
    if (registros.length === 0) {
        grid.innerHTML = '<div class="empty-state"><h3>No se encontraron registros</h3><p>Intenta cambiar los filtros de búsqueda</p></div>';
        return;
    }
    
    // Renderizar registros
    grid.innerHTML = registros.map(record => {
        const previewImage = record.media_preview && record.media_preview.length > 0 ? record.media_preview[0].datos_base64 : null;
        
        return `
        <div class="record-card">
            ${previewImage ? `
            <div class="record-image-preview">
                <img src="${previewImage}" alt="Preview" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px 8px 0 0;">
            </div>
            ` : ''}
            <div class="record-header">
                <h3>${escapeHtml(record.nombre || record.descripcion_breve || record.tipo_actividad || 'Sin título')}</h3>
                <div class="record-actions">
                    <button class="btn-icon edit" onclick="editRecordAdmin(${record.id})" title="Editar">✏️</button>
                    <button class="btn-icon delete" onclick="deleteRecordAdmin(${record.id})" title="Eliminar">🗑️</button>
                </div>
            </div>
            <div class="record-body">
                ${record.especie ? `<p><strong>Especie:</strong> ${escapeHtml(record.especie)}</p>` : ''}
                ${record.categoria_nombre ? `<p><strong>Categoría:</strong> ${escapeHtml(record.categoria_nombre)}</p>` : ''}
                ${record.subcategoria_nombre ? `<p><strong>Subcategoría:</strong> ${escapeHtml(record.subcategoria_nombre)}</p>` : ''}
                ${record.fecha ? `<p><strong>Fecha:</strong> ${formatDate(record.fecha)}</p>` : ''}
                ${record.usuario_nombre ? `<p><strong>Usuario:</strong> ${escapeHtml(record.usuario_nombre)}</p>` : ''}
                ${record.has_media ? `<p><strong>Media:</strong> ${record.media_count} archivo(s)${record.media_count > 1 ? ' (mostrando preview)' : ''}</p>` : ''}
            </div>
        </div>
        `;
    }).join('');
}

function filterRegistros() {
    // Limpiar timeout anterior
    if (searchTimeout) {
        clearTimeout(searchTimeout);
    }
    
    // Debounce: esperar 500ms después de que el usuario deje de escribir
    searchTimeout = setTimeout(() => {
        loadAllRegistros();
    }, 500);
}

async function editRecordAdmin(recordId) {
    try {
        // Obtener el registro completo desde la API
        const response = await fetch(`../api/api.php?action=get_registros_ambientales&id=${recordId}`);
        const data = await response.json();
        
        if (data.success && data.record) {
            const record = data.record;
            // Guardar TODOS los campos del registro para edición (igual que en script.js)
            const editingRecord = {
                id: record.id,
                usuario_id: record.usuario_id,
                categoria_id: record.categoria_id,
                subcategoria_id: record.subcategoria_id,
                nombre: record.nombre || null,
                especie: record.especie || null,
                fecha: record.fecha,
                hora: record.hora || null,
                responsable: record.responsable || null,
                brigada: record.brigada || null,
                latitud: record.latitud,
                longitud: record.longitud,
                altitud: record.altitud || null,
                comunidad: record.comunidad || null,
                sitio: record.sitio || null,
                tipo_actividad: record.tipo_actividad || null,
                descripcion_breve: record.descripcion_breve || null,
                observaciones: record.observaciones || null,
                materiales_utilizados: record.materiales_utilizados || null,
                numero_participantes: record.numero_participantes || null,
                notas: record.notas || null,
                media: record.media || [],
                fecha_creacion: record.fecha_creacion
            };
            
            // Guardar en sessionStorage con la clave que espera el formulario
            sessionStorage.setItem('editingRecord', JSON.stringify(editingRecord));
            // Marcar que viene del panel de administración
            sessionStorage.setItem('editingFromAdmin', 'true');
            console.log('✅ Marcado editingFromAdmin = true, redirigiendo a formulario');
            window.location.href = 'nuevo-registro.html?edit=true';
        } else {
            alert('Error: No se pudo cargar el registro para editar');
        }
    } catch (error) {
        console.error('Error al cargar registro para editar:', error);
        alert('Error de conexión al cargar el registro');
    }
}

async function deleteRecordAdmin(recordId) {
    if (!confirm('¿Estás seguro de eliminar este registro?')) {
        return;
    }
    
    try {
        const response = await fetch('../api/api.php?action=delete_record', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: recordId })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Registro eliminado exitosamente');
            loadAllRegistros();
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al eliminar registro');
    }
}

// ==================== CATEGORÍAS ====================
async function loadCategorias() {
    try {
        const response = await fetch('../api/api.php?action=get_categorias');
        const data = await response.json();
        
        if (data.success && data.categorias) {
            allCategorias = data.categorias;
            renderCategorias(allCategorias);
            populateCategoriaFilter();
        }
    } catch (error) {
        console.error('Error al cargar categorías:', error);
    }
}

function populateCategoriaFilter() {
    const select = document.getElementById('filterCategoriaAdmin');
    if (!select) return;
    
    // Limpiar opciones existentes excepto la primera
    select.innerHTML = '<option value="">Todas las categorías</option>';
    
    if (allCategorias && allCategorias.length > 0) {
        allCategorias.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat.id;
            option.textContent = cat.nombre;
            select.appendChild(option);
        });
    }
}

function renderCategorias(categorias) {
    const container = document.getElementById('categoriasContainer');
    if (!container) return;
    
    if (!categorias || categorias.length === 0) {
        container.innerHTML = '<div class="empty-state"><h3>No hay categorías</h3></div>';
        return;
    }
    
    // Agrupar categorías con sus subcategorías
    let html = '<div class="categorias-list">';
    
    categorias.forEach(categoria => {
        html += `
            <div class="categoria-item" style="background: white; border-radius: 8px; padding: 1.5rem; margin-bottom: 1rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <h3 style="margin: 0; color: #2c7a7b; font-size: 1.2rem;">${escapeHtml(categoria.nombre)}</h3>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn-icon edit" onclick="editCategoria(${categoria.id})" title="Editar">✏️</button>
                        <button class="btn-icon delete" onclick="deleteCategoria(${categoria.id})" title="Eliminar">🗑️</button>
                    </div>
                </div>
                <p style="color: #666; margin: 0 0 1rem 0; font-size: 0.9rem;">${escapeHtml(categoria.descripcion || 'Sin descripción')}</p>
                <div class="subcategorias-list" id="subcategorias-${categoria.id}">
                    <div class="loading-state" style="font-size: 0.85rem; color: #999;">Cargando subcategorías...</div>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    container.innerHTML = html;
    
    // Cargar subcategorías para cada categoría
    categorias.forEach(categoria => {
        loadSubcategoriasForCategoria(categoria.id);
    });
}

async function loadSubcategoriasForCategoria(categoriaId) {
    try {
        const response = await fetch(`../api/api.php?action=get_subcategorias&categoria_id=${categoriaId}`);
        const data = await response.json();
        
        const container = document.getElementById(`subcategorias-${categoriaId}`);
        if (!container) return;
        
        if (data.success && data.subcategorias && data.subcategorias.length > 0) {
            let html = '<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 0.75rem;">';
            data.subcategorias.forEach(sub => {
                html += `
                    <div style="background: #f7fafc; padding: 0.75rem; border-radius: 6px; border-left: 3px solid #2c7a7b;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <strong style="color: #333; font-size: 0.9rem;">${escapeHtml(sub.nombre)}</strong>
                                ${sub.descripcion ? `<p style="margin: 0.25rem 0 0 0; color: #666; font-size: 0.8rem;">${escapeHtml(sub.descripcion)}</p>` : ''}
                            </div>
                            <div style="display: flex; gap: 0.25rem;">
                                <button class="btn-icon edit" onclick="editSubcategoria(${sub.id})" title="Editar" style="font-size: 0.8rem;">✏️</button>
                                <button class="btn-icon delete" onclick="deleteSubcategoria(${sub.id})" title="Eliminar" style="font-size: 0.8rem;">🗑️</button>
                            </div>
                        </div>
                    </div>
                `;
            });
            html += '</div>';
            container.innerHTML = html;
        } else {
            container.innerHTML = '<p style="color: #999; font-size: 0.85rem; font-style: italic;">No hay subcategorías</p>';
        }
    } catch (error) {
        console.error('Error al cargar subcategorías:', error);
        const container = document.getElementById(`subcategorias-${categoriaId}`);
        if (container) {
            container.innerHTML = '<p style="color: #d32f2f; font-size: 0.85rem;">Error al cargar subcategorías</p>';
        }
    }
}

function editCategoria(id) {
    alert('Función de editar categoría próximamente');
}

function deleteCategoria(id) {
    if (confirm('¿Estás seguro de eliminar esta categoría? Esto también eliminará todas sus subcategorías y registros asociados.')) {
        alert('Función de eliminar categoría próximamente');
    }
}

function editSubcategoria(id) {
    alert('Función de editar subcategoría próximamente');
}

function deleteSubcategoria(id) {
    if (confirm('¿Estás seguro de eliminar esta subcategoría?')) {
        alert('Función de eliminar subcategoría próximamente');
    }
}

function showAddCategoriaModal() {
    alert('Función de agregar categoría próximamente');
}

// ==================== COMENTARIOS ====================
async function loadComentarios() {
    try {
        const response = await fetch('../api/api.php?action=get_all_comentarios');
        const data = await response.json();
        
        if (data.success) {
            allComentarios = data.comentarios || [];
            renderComentarios(allComentarios);
        } else {
            const container = document.getElementById('comentariosContainer');
            if (container) {
                container.innerHTML = '<div class="empty-state"><h3>Error al cargar comentarios</h3></div>';
            }
        }
    } catch (error) {
        console.error('Error al cargar comentarios:', error);
        const container = document.getElementById('comentariosContainer');
        if (container) {
            container.innerHTML = '<div class="empty-state"><h3>Error de conexión</h3></div>';
        }
    }
}

function renderComentarios(comentarios) {
    const container = document.getElementById('comentariosContainer');
    if (!container) return;
    
    if (!comentarios || comentarios.length === 0) {
        container.innerHTML = '<div class="empty-state"><h3>No hay comentarios</h3></div>';
        return;
    }
    
    let html = '<div class="comentarios-list">';
    
    comentarios.forEach(comentario => {
        const activoClass = comentario.activo ? 'badge-success' : 'badge-danger';
        const activoText = comentario.activo ? 'Activo' : 'Inactivo';
        
        html += `
            <div class="comentario-card" style="background: white; border-radius: 8px; padding: 1.5rem; margin-bottom: 1rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                            <strong style="color: #2c7a7b; font-size: 1rem;">${escapeHtml(comentario.usuario_nombre || 'Usuario desconocido')}</strong>
                            <span class="badge ${activoClass}" style="font-size: 0.75rem; padding: 0.25rem 0.5rem;">${activoText}</span>
                        </div>
                        <p style="color: #666; font-size: 0.85rem; margin: 0;">
                            Registro ID: ${comentario.registro_id} | ${formatDate(comentario.fecha_creacion)}
                        </p>
                    </div>
                    <div style="display: flex; gap: 0.5rem;">
                        ${comentario.activo ? 
                            `<button class="btn-icon delete" onclick="toggleComentario(${comentario.id}, false)" title="Desactivar">🚫</button>` :
                            `<button class="btn-icon activate" onclick="toggleComentario(${comentario.id}, true)" title="Activar">✅</button>`
                        }
                        <button class="btn-icon delete" onclick="deleteComentario(${comentario.id})" title="Eliminar">🗑️</button>
                    </div>
                </div>
                <div style="background: #f7fafc; padding: 1rem; border-radius: 6px; border-left: 3px solid #2c7a7b;">
                    <p style="margin: 0; color: #333; line-height: 1.6;">${escapeHtml(comentario.comentario || 'Sin comentario')}</p>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    container.innerHTML = html;
}

async function toggleComentario(id, activo) {
    if (!confirm(`¿Estás seguro de ${activo ? 'activar' : 'desactivar'} este comentario?`)) {
        return;
    }
    
    try {
        const response = await fetch('../api/api.php?action=update_comentario', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, activo: activo ? 1 : 0 })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Comentario actualizado exitosamente');
            loadComentarios();
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al actualizar comentario');
    }
}

async function deleteComentario(id) {
    if (!confirm('¿Estás seguro de eliminar este comentario? Esta acción no se puede deshacer.')) {
        return;
    }
    
    try {
        const response = await fetch('../api/api.php?action=delete_comentario', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Comentario eliminado exitosamente');
            loadComentarios();
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al eliminar comentario');
    }
}

function filterComentarios() {
    const search = document.getElementById('searchComentarios')?.value.toLowerCase() || '';
    const activo = document.getElementById('filterComentarioActivo')?.value || '';
    
    let filtered = [...allComentarios];
    
    if (search) {
        filtered = filtered.filter(comentario => {
            const texto = (comentario.comentario || '').toLowerCase();
            const usuario = (comentario.usuario_nombre || '').toLowerCase();
            return texto.includes(search) || usuario.includes(search);
        });
    }
    
    if (activo !== '') {
        filtered = filtered.filter(comentario => comentario.activo == activo);
    }
    
    renderComentarios(filtered);
}

// ==================== UTILIDADES ====================
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('es-MX', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function adminLogout() {
    if (confirm('¿Deseas cerrar sesión como administrador?')) {
        if (window.adminAuthSystem) {
            window.adminAuthSystem.logout();
        }
        window.location.href = 'admin-login.html';
    }
}


<?php
// Script simple para probar la API
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Test API</title>
</head>
<body>
    <h1>Test de API</h1>
    <p>Si ves este mensaje, PHP está funcionando correctamente.</p>
    <p><a href="api.php?action=test">Probar API</a></p>
    <p><a href="test_connection.php">Probar Conexión a BD</a></p>
    <p><a href="registro.html">Ir a Registro</a></p>
</body>
</html>


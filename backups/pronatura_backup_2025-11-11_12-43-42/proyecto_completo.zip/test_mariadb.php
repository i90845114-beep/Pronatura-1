<?php
require_once __DIR__ . '/../api/db_connection.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conexión MariaDB - ProNatura</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 900px;
            margin: 20px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .success {
            color: #4caf50;
            background: #e8f5e9;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .error {
            color: #f44336;
            background: #ffebee;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .info {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        h1 {
            color: #2c7a7b;
        }
        pre {
            background: #f5f5f5;
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 10px 0;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #2c7a7b;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🗄️ Conexión a MariaDB (phpMyAdmin)</h1>
        
        <?php
        try {
            $db = new DatabaseConnection();
            
            echo '<div class="info">';
            echo '<h3>📋 Configuración desde config.json:</h3>';
            $configFile = __DIR__ . '/../config/config.json';
            $configContent = file_get_contents($configFile);
            $config = json_decode($configContent, true);
            $config['database']['password'] = str_repeat('*', strlen($config['database']['password']));
            echo '<pre>' . json_encode($config, JSON_PRETTY_PRINT) . '</pre>';
            echo '</div>';
            
            $conn = $db->connect();
            
            echo '<div class="success">';
            echo '<h3>✅ Conexión Exitosa a MariaDB</h3>';
            echo '<p>La conexión a la base de datos se estableció correctamente.</p>';
            echo '</div>';
            
            echo '<div class="info">';
            echo '<h3>📊 Información del Servidor MariaDB:</h3>';
            
            $stmt = $conn->query("SELECT VERSION() as version, DATABASE() as database_name, CURRENT_USER() as usuario_actual, NOW() as server_time");
            $serverInfo = $stmt->fetch();
            
            echo '<table>';
            echo '<tr><th>Propiedad</th><th>Valor</th></tr>';
            echo '<tr><td><strong>Versión MariaDB</strong></td><td>' . htmlspecialchars($serverInfo['version']) . '</td></tr>';
            echo '<tr><td><strong>Base de Datos Conectada</strong></td><td>' . htmlspecialchars($serverInfo['database_name']) . '</td></tr>';
            echo '<tr><td><strong>Usuario Actual</strong></td><td>' . htmlspecialchars($serverInfo['usuario_actual']) . '</td></tr>';
            echo '<tr><td><strong>Hora del Servidor</strong></td><td>' . htmlspecialchars($serverInfo['server_time']) . '</td></tr>';
            echo '</table>';
            echo '</div>';
            
            echo '<div class="info">';
            echo '<h3>📑 Tablas en la Base de Datos:</h3>';
            $stmt = $conn->query("SHOW TABLES");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            if (count($tables) > 0) {
                echo '<ul>';
                foreach ($tables as $table) {
                    $stmt = $conn->query("SELECT COUNT(*) as count FROM `$table`");
                    $count = $stmt->fetch()['count'];
                    echo '<li><strong>' . htmlspecialchars($table) . '</strong> - ' . $count . ' registro(s)</li>';
                }
                echo '</ul>';
            } else {
                echo '<p>No hay tablas en la base de datos.</p>';
            }
            echo '</div>';
            
            echo '<div class="info">';
            echo '<h3>👥 Usuarios Registrados:</h3>';
            $stmt = $conn->query("SELECT id, nombre, email, rol, fecha_registro FROM usuarios ORDER BY fecha_registro DESC");
            $users = $stmt->fetchAll();
            
            if (count($users) > 0) {
                echo '<table>';
                echo '<tr><th>ID</th><th>Nombre</th><th>Email</th><th>Rol</th><th>Fecha Registro</th></tr>';
                foreach ($users as $user) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($user['id']) . '</td>';
                    echo '<td>' . htmlspecialchars($user['nombre']) . '</td>';
                    echo '<td>' . htmlspecialchars($user['email']) . '</td>';
                    echo '<td>' . htmlspecialchars($user['rol']) . '</td>';
                    echo '<td>' . htmlspecialchars($user['fecha_registro']) . '</td>';
                    echo '</tr>';
                }
                echo '</table>';
            } else {
                echo '<p>No hay usuarios registrados.</p>';
            }
            echo '</div>';
            
            echo '<div class="success">';
            echo '<h3>✅ Estado de la Conexión</h3>';
            echo '<p>✓ Conexión a MariaDB establecida correctamente</p>';
            echo '<p>✓ Base de datos "' . htmlspecialchars($config['database']['database']) . '" accesible</p>';
            echo '<p>✓ Configuración desde config.json cargada correctamente</p>';
            echo '<p>✓ Listo para usar en la aplicación</p>';
            echo '</div>';
            
        } catch (Exception $e) {
            echo '<div class="error">';
            echo '<h3>❌ Error de Conexión</h3>';
            echo '<p><strong>Mensaje:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>';
            echo '<p><strong>Soluciones:</strong></p>';
            echo '<ul>';
            echo '<li>Verifica que MariaDB esté corriendo en XAMPP</li>';
            echo '<li>Revisa las credenciales en config.json</li>';
            echo '<li>Asegúrate de que la base de datos "' . (isset($config) ? htmlspecialchars($config['database']['database']) : 'db') . '" exista</li>';
            echo '<li>Verifica el puerto (por defecto 3306)</li>';
            echo '</ul>';
            echo '</div>';
        }
        ?>
        
        <div class="info" style="margin-top: 20px;">
            <h3>🔗 Acceso a phpMyAdmin</h3>
            <p>Puedes acceder a phpMyAdmin en: <a href="http://localhost/phpmyadmin" target="_blank">http://localhost/phpmyadmin</a></p>
            <p><strong>Base de datos:</strong> <?php echo isset($config) ? htmlspecialchars($config['database']['database']) : 'db'; ?></p>
            <p><strong>Usuario:</strong> <?php echo isset($config) ? htmlspecialchars($config['database']['user']) : 'root'; ?></p>
        </div>
        
        <p style="margin-top: 20px;">
            <a href="test_connection.php">← Volver al test de conexión</a> |
            <a href="migrate_users.php">Gestionar usuarios</a>
        </p>
    </div>
</body>
</html>


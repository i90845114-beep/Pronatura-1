<?php
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Diagnóstico PHP - ProNatura</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 900px; margin: 20px auto; padding: 20px; }
        .ok { color: green; }
        .error { color: red; }
        .warning { color: orange; }
        pre { background: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }
        h2 { color: #2c7a7b; }
    </style>
</head>
<body>
    <h1>🔍 Diagnóstico de Configuración PHP</h1>
    
    <h2>Extensiones PHP</h2>
    <ul>
        <li>PDO: <?php echo extension_loaded('pdo') ? '<span class="ok">✓ Instalado</span>' : '<span class="error">✗ No instalado</span>'; ?></li>
        <li>PDO MySQL: <?php echo extension_loaded('pdo_mysql') ? '<span class="ok">✓ Instalado</span>' : '<span class="error">✗ No instalado</span>'; ?></li>
        <li>MySQLi: <?php echo extension_loaded('mysqli') ? '<span class="ok">✓ Instalado</span>' : '<span class="warning">⚠ No instalado (opcional)</span>'; ?></li>
    </ul>
    
    <h2>Configuración de Base de Datos</h2>
    <?php
    $configFile = __DIR__ . '/../config/config.json';
    if (file_exists($configFile)) {
        $config = json_decode(file_get_contents($configFile), true);
        echo '<pre>' . json_encode($config, JSON_PRETTY_PRINT) . '</pre>';
    } else {
        echo '<p class="error">No se encontró config.json</p>';
    }
    ?>
    
    <h2>Prueba de Conexión Directa</h2>
    <?php
    if (file_exists($configFile)) {
        $config = json_decode(file_get_contents($configFile), true);
        $db = $config['database'];
        
        try {
            $dsn = "mysql:host={$db['host']};port={$db['port']};charset={$db['charset']}";
            $pdo = new PDO($dsn, $db['user'], $db['password']);
            echo '<p class="ok">✓ Conexión a MySQL exitosa (sin base de datos)</p>';
            
            try {
                $pdo->exec("USE `{$db['database']}`");
                echo '<p class="ok">✓ Base de datos "'.$db['database'].'" existe y es accesible</p>';
                
                $stmt = $pdo->query("SHOW TABLES");
                $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
                echo '<p><strong>Tablas encontradas:</strong> ' . count($tables) . '</p>';
                if (count($tables) > 0) {
                    echo '<ul>';
                    foreach ($tables as $table) {
                        echo '<li>' . htmlspecialchars($table) . '</li>';
                    }
                    echo '</ul>';
                }
            } catch (PDOException $e) {
                echo '<p class="error">✗ Error al acceder a la base de datos: ' . htmlspecialchars($e->getMessage()) . '</p>';
            }
            
        } catch (PDOException $e) {
            echo '<p class="error">✗ Error de conexión: ' . htmlspecialchars($e->getMessage()) . '</p>';
            echo '<p><strong>Posibles soluciones:</strong></p>';
            echo '<ul>';
            echo '<li>Verifica que MySQL esté corriendo en XAMPP</li>';
            echo '<li>Verifica usuario y contraseña</li>';
            echo '<li>Verifica el puerto (actual: ' . $db['port'] . ')</li>';
            echo '</ul>';
        }
    }
    ?>
    
    <h2>Información del Sistema</h2>
    <ul>
        <li>Versión PHP: <?php echo phpversion(); ?></li>
        <li>Sistema Operativo: <?php echo PHP_OS; ?></li>
        <li>Directorio actual: <?php echo __DIR__; ?></li>
    </ul>
    
    <p><a href="test_connection.php">← Volver al test de conexión</a></p>
</body>
</html>


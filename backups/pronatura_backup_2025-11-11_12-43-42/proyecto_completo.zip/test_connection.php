<?php
require_once __DIR__ . '/../api/db_connection.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test de Conexión - ProNatura</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .success {
            color: #4caf50;
            background: #e8f5e9;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .error {
            color: #f44336;
            background: #ffebee;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .info {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        h1 {
            color: #2c7a7b;
        }
        pre {
            background: #f5f5f5;
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔌 Test de Conexión a Base de Datos</h1>
        
        <?php
        try {
            $db = new DatabaseConnection();
            
            echo '<div class="info">';
            echo '<h3>📋 Configuración Cargada:</h3>';
            $configFile = __DIR__ . '/../config/config.json';
            $configContent = file_get_contents($configFile);
            $config = json_decode($configContent, true);
            $config['database']['password'] = str_repeat('*', strlen($config['database']['password']));
            echo '<pre>' . json_encode($config, JSON_PRETTY_PRINT) . '</pre>';
            echo '</div>';
            
            if ($db->testConnection()) {
                echo '<div class="success">';
                echo '<h3>✅ Conexión Exitosa</h3>';
                echo '<p>La conexión a la base de datos se estableció correctamente.</p>';
                echo '</div>';
                
                $conn = $db->getConnection();
                
                echo '<div class="info">';
                echo '<h3>📊 Información de la Base de Datos:</h3>';
                
                $stmt = $conn->query("SELECT DATABASE() as db_name, VERSION() as db_version");
                $info = $stmt->fetch();
                echo '<p><strong>Base de datos:</strong> ' . htmlspecialchars($info['db_name']) . '</p>';
                echo '<p><strong>Versión MySQL:</strong> ' . htmlspecialchars($info['db_version']) . '</p>';
                
                echo '<h4>📑 Tablas Existentes:</h4>';
                $stmt = $conn->query("SHOW TABLES");
                $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                if (count($tables) > 0) {
                    echo '<ul>';
                    foreach ($tables as $table) {
                        echo '<li>' . htmlspecialchars($table) . '</li>';
                    }
                    echo '</ul>';
                } else {
                    echo '<p>No hay tablas en la base de datos. Ejecuta el script db.sql para crear las tablas.</p>';
                }
                
                echo '</div>';
                
            } else {
                throw new Exception("No se pudo establecer la conexión");
            }
            
        } catch (Exception $e) {
            echo '<div class="error">';
            echo '<h3>❌ Error de Conexión</h3>';
            echo '<p><strong>Mensaje:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>';
            
            $errorMsg = $e->getMessage();
            $configFile = __DIR__ . '/../config/config.json';
            if (file_exists($configFile)) {
                $configContent = file_get_contents($configFile);
                $config = json_decode($configContent, true);
                echo '<p><strong>Base de datos configurada:</strong> ' . htmlspecialchars($config['database']['database']) . '</p>';
            }
            
            echo '<p><strong>Diagnóstico:</strong></p>';
            echo '<ul>';
            
            if (strpos($errorMsg, 'Access denied') !== false) {
                echo '<li>❌ <strong>Error de autenticación:</strong> Verifica usuario y contraseña en config.json</li>';
            } elseif (strpos($errorMsg, "Unknown database") !== false) {
                echo '<li>❌ <strong>Base de datos no existe:</strong> Crea la base de datos primero</li>';
            } elseif (strpos($errorMsg, "Connection refused") !== false || strpos($errorMsg, "Can't connect") !== false) {
                echo '<li>❌ <strong>MySQL no está corriendo:</strong> Inicia MySQL desde el panel de control de XAMPP</li>';
            } else {
                echo '<li>❌ <strong>Error desconocido:</strong> ' . htmlspecialchars($errorMsg) . '</li>';
            }
            
            echo '<li>Verifica que MySQL esté corriendo en XAMPP (Panel de Control)</li>';
            echo '<li>Revisa las credenciales en config.json</li>';
            echo '<li>Asegúrate de que la base de datos "' . (isset($config) ? htmlspecialchars($config['database']['database']) : 'db') . '" exista</li>';
            echo '<li>Verifica el puerto (por defecto 3306)</li>';
            echo '</ul>';
            echo '</div>';
        }
        ?>
        
        <div class="info" style="margin-top: 20px;">
            <h3>📝 Próximos Pasos:</h3>
            <ol>
                <li>Si la conexión falla, verifica config.json</li>
                <li>Ejecuta db.sql en MySQL para crear las tablas</li>
                <li>Usa db_connection.php en tus scripts PHP</li>
            </ol>
        </div>
    </div>
</body>
</html>


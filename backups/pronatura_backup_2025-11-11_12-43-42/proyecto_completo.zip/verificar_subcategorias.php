<?php
/**
 * Script para verificar y mostrar todas las subcategorías
 * Identifica palabras incompletas o con problemas de codificación
 */

require_once __DIR__ . '/../api/db_connection.php';

header('Content-Type: text/html; charset=utf-8');

try {
    $conn = getDB();
    
    echo "<h1>Verificación de Subcategorías</h1>";
    echo "<pre style='font-family: monospace; font-size: 12px;'>";
    
    // Obtener todas las subcategorías con su categoría
    $stmt = $conn->query("SELECT s.id, s.codigo, s.nombre, c.nombre as categoria_nombre 
                          FROM subcategorias s 
                          INNER JOIN categorias c ON s.categoria_id = c.id 
                          ORDER BY c.orden, s.orden");
    $subcategorias = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Total de subcategorías: " . count($subcategorias) . "\n\n";
    echo "=== LISTA DE SUBCATEGORÍAS ===\n\n";
    
    $categoriaActual = '';
    $problemas = [];
    
    foreach ($subcategorias as $subcat) {
        if ($categoriaActual !== $subcat['categoria_nombre']) {
            $categoriaActual = $subcat['categoria_nombre'];
            echo "\n📁 {$categoriaActual}\n";
            echo str_repeat('-', 60) . "\n";
        }
        
        $nombre = $subcat['nombre'];
        echo "  [{$subcat['codigo']}] {$nombre}\n";
        
        // Detectar problemas comunes
        if (preg_match('/ian\b/i', $nombre) && !preg_match('/ción\b/i', $nombre)) {
            $problemas[] = [
                'id' => $subcat['id'],
                'codigo' => $subcat['codigo'],
                'nombre' => $nombre,
                'problema' => 'Termina en "ian" (posible "ión" incompleto)'
            ];
        }
        
        if (preg_match('/astica\b/i', $nombre) && !preg_match('/ística\b/i', $nombre)) {
            $problemas[] = [
                'id' => $subcat['id'],
                'codigo' => $subcat['codigo'],
                'nombre' => $nombre,
                'problema' => 'Contiene "astica" (posible "ística" incompleto)'
            ];
        }
    }
    
    if (count($problemas) > 0) {
        echo "\n\n⚠️ PROBLEMAS DETECTADOS:\n";
        echo str_repeat('=', 60) . "\n";
        foreach ($problemas as $problema) {
            echo "ID: {$problema['id']} | Código: {$problema['codigo']}\n";
            echo "  Nombre: {$problema['nombre']}\n";
            echo "  Problema: {$problema['problema']}\n\n";
        }
    } else {
        echo "\n\n✅ No se detectaron problemas obvios.\n";
    }
    
    echo "</pre>";
    
} catch (Exception $e) {
    echo "<pre>Error: " . $e->getMessage() . "</pre>";
}


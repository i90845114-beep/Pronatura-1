# ProNatura - Sistema de Registro de Fauna Silvestre

Sistema web para el registro y seguimiento de fauna silvestre en Tamaulipas.

## 📁 Estructura del Proyecto

```
pronatura/
├── api/                    # Archivos PHP de la API
│   ├── api.php            # Endpoint principal de la API
│   └── db_connection.php  # Conexión a la base de datos
│
├── pages/                  # Páginas HTML
│   ├── index.html         # Página principal (Biblioteca)
│   ├── login.html         # Inicio de sesión
│   ├── registro.html      # Registro de usuarios
│   ├── nuevo-registro.html # Formulario de nuevo registro
│   ├── mapa-consolidado.html # Mapa con todos los registros
│   ├── bloc-notas.html    # Bloc de notas
│   └── inicio.html        # Página de inicio/landing
│
├── assets/                 # Recursos estáticos
│   ├── css/
│   │   └── styles.css     # Estilos principales
│   └── js/
│       ├── auth.js        # Sistema de autenticación
│       ├── script.js      # Lógica principal
│       └── form-script.js # Lógica del formulario
│
├── config/                 # Configuración
│   ├── config.json        # Configuración de la base de datos
│   └── config.example.json # Ejemplo de configuración
│
├── database/               # Scripts de base de datos
│   └── db.sql            # Script SQL para crear tablas
│
├── scripts/                # Scripts de utilidad
│   └── ejecutar_db.ps1   # Script PowerShell para ejecutar db.sql
│
├── tests/                  # Archivos de prueba y diagnóstico
│   ├── test_connection.php
│   ├── test_mariadb.php
│   ├── verificar_bd.php
│   ├── verificar_usuario.php
│   ├── check_php_config.php
│   └── migrate_users.php
│
└── docs/                   # Documentación
    └── ESTRUCTURA_BASE_DATOS.md
```

## 🚀 Instalación

1. **Configurar la base de datos:**
   - Copia `config/config.example.json` a `config/config.json`
   - Edita `config/config.json` con tus credenciales de MySQL

2. **Crear la base de datos:**
   ```powershell
   cd scripts
   .\ejecutar_db.ps1
   ```

3. **Acceder a la aplicación:**
   - Abre `http://localhost/pronatura/pages/index.html` en tu navegador
   - O `http://localhost/pronatura/pages/login.html` para iniciar sesión

## 📝 Notas Importantes

- **Siempre accede a las páginas desde `http://localhost/pronatura/pages/`** (no desde `file://`)
- La base de datos configurada es **"db"** (verificar en `config/config.json`)
- Asegúrate de que Apache y MySQL estén corriendo en XAMPP

## 🔧 Configuración

El archivo `config/config.json` contiene la configuración de la base de datos:

```json
{
    "database": {
        "host": "localhost",
        "port": 3306,
        "database": "db",
        "user": "root",
        "password": "",
        "charset": "utf8mb4",
        "timezone": "America/Mexico_City"
    }
}
```

## 📚 Documentación

Ver `docs/ESTRUCTURA_BASE_DATOS.md` para más información sobre la estructura de la base de datos.


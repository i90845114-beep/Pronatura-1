<?php
/**
 * Script para corregir palabras incompletas en subcategorías
 * Corrige problemas de codificación UTF-8 y palabras truncadas
 */

require_once __DIR__ . '/../api/db_connection.php';

header('Content-Type: text/html; charset=utf-8');

try {
    $conn = getDB();
    
    echo "<h1>Corrección de Subcategorías</h1>";
    echo "<pre>";
    
    // Correcciones específicas a aplicar (palabras completas)
    $correccionesEspecificas = [
        'Evaluacian' => 'Evaluación',
        'Logastica' => 'Logística',
        'Capacitacian' => 'Capacitación',
        'Capacitacian Interna' => 'Capacitación Interna',
    ];
    
    // Patrones de corrección para palabras que terminan incorrectamente
    $patronesCorreccion = [
        // Palabras que terminan en "ian" → "ión"
        '/\bEvaluacian\b/i' => 'Evaluación',
        '/\bCapacitacian\b/i' => 'Capacitación',
        '/\bOrganizacian\b/i' => 'Organización',
        '/\bRestauracan\b/i' => 'Restauración',
        '/\bEducacian\b/i' => 'Educación',
        '/\bComunicacian\b/i' => 'Comunicación',
        '/\bDifusian\b/i' => 'Difusión',
        '/\bCoordinacian\b/i' => 'Coordinación',
        '/\bDelimitacian\b/i' => 'Delimitación',
        '/\bSeñalizacian\b/i' => 'Señalización',
        
        // Palabras con "astica" → "ística"
        '/\bLogastica\b/i' => 'Logística',
        
        // Otras correcciones comunes
        '/\bRecorridos de Camp\b/i' => 'Recorridos de Campo',
    ];
    
    // Obtener todas las subcategorías
    $stmt = $conn->query("SELECT id, codigo, nombre FROM subcategorias");
    $subcategorias = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Total de subcategorías encontradas: " . count($subcategorias) . "\n\n";
    
    $corregidas = 0;
    
    foreach ($subcategorias as $subcat) {
        $nombreOriginal = $subcat['nombre'];
        $nombreCorregido = $nombreOriginal;
        
        // Aplicar correcciones específicas primero
        foreach ($correccionesEspecificas as $incorrecto => $correcto) {
            if (stripos($nombreCorregido, $incorrecto) !== false) {
                $nombreCorregido = str_ireplace($incorrecto, $correcto, $nombreCorregido);
            }
        }
        
        // Aplicar correcciones por patrones
        foreach ($patronesCorreccion as $patron => $reemplazo) {
            $nombreCorregido = preg_replace($patron, $reemplazo, $nombreCorregido);
        }
        
        // Si se hizo alguna corrección, actualizar en la base de datos
        if ($nombreCorregido !== $nombreOriginal) {
            echo "Corrigiendo ID {$subcat['id']} [{$subcat['codigo']}]:\n";
            echo "  Antes: '{$nombreOriginal}'\n";
            echo "  Después: '{$nombreCorregido}'\n\n";
            
            $updateStmt = $conn->prepare("UPDATE subcategorias SET nombre = ? WHERE id = ?");
            $updateStmt->execute([$nombreCorregido, $subcat['id']]);
            
            $corregidas++;
        }
    }
    
    echo "\n";
    echo "Total de subcategorías corregidas: {$corregidas}\n";
    echo "\n✅ Proceso completado.\n";
    
    // Mostrar todas las subcategorías actualizadas
    echo "\n=== Subcategorías actuales ===\n";
    $stmt = $conn->query("SELECT s.id, s.nombre, c.nombre as categoria_nombre 
                          FROM subcategorias s 
                          INNER JOIN categorias c ON s.categoria_id = c.id 
                          ORDER BY c.orden, s.orden");
    $todas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($todas as $subcat) {
        echo "- [{$subcat['categoria_nombre']}] {$subcat['nombre']}\n";
    }
    
    echo "</pre>";
    
} catch (Exception $e) {
    echo "<pre>Error: " . $e->getMessage() . "</pre>";
}


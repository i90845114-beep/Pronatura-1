<?php
require_once __DIR__ . '/../api/db_connection.php';

header('Content-Type: text/html; charset=utf-8');

try {
    $conn = getDB();
    
    // Leer el archivo SQL
    $sql = file_get_contents(__DIR__ . '/../database/admin_sessions.sql');
    
    if ($sql === false) {
        throw new Exception('No se pudo leer el archivo admin_sessions.sql');
    }
    
    // Ejecutar el SQL
    $conn->exec($sql);
    
    echo "<h2>✅ Tabla admin_sessions creada exitosamente</h2>";
    echo "<p>La tabla <strong>admin_sessions</strong> ha sido creada en la base de datos.</p>";
    echo "<p><a href='../pages/admin-login.html'>Ir al login de administradores</a></p>";
    
} catch (Exception $e) {
    echo "<h2>❌ Error</h2>";
    echo "<p style='color: red;'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    
    if (strpos($e->getMessage(), 'already exists') !== false) {
        echo "<p>La tabla ya existe. Esto es normal si ya la creaste antes.</p>";
    }
}
?>

